﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    /// <summary>
    /// 枚举对象帮助类
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// 获取枚举对象的文档说明
        /// </summary>
        /// <param name="en"></param>
        /// <returns></returns>
        public static string GetDesc(this Enum en)
        {
            Type type = en.GetType();
            System.Reflection.MemberInfo[] memberIfo = type.GetMember(en.ToString());
            if (memberIfo != null && memberIfo.Length > 0)
            {
                Attribute attrs = memberIfo[0].GetCustomAttribute(typeof(System.ComponentModel.DescriptionAttribute), false);
                if (attrs != null)
                {
                    return (attrs as System.ComponentModel.DescriptionAttribute).Description;
                }
            }

            return en.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="en"></param>
        /// <returns></returns>
        public static Dictionary<string, int> GetDescAndValue(Type en)
        {
            if (!en.IsEnum)
            {
                return null;
            }
            object temp = null;
            Array arrays = Enum.GetValues(en);
            Dictionary<string, int> dic = new Dictionary<string, int>();
            for (int i = 0, len = arrays.Length; i < len; i++)
            {
                temp = arrays.GetValue(i);
                dic.Add(GetDesc((Enum)temp), (int)temp);
            }

            return dic;

        }
    }
}
