﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    public class RandomHelper
    {
        /// <summary>
        /// 获取任意位随机串符串【不推荐使用效率太低】
        /// </summary>
        /// <param name="length"></param>
        /// <param name="hasNumber"></param>
        /// <returns></returns>
        public static string RandomString(int length = 16, bool hasNumber = true)
        {
            long tempNum = 0;
            long baseNum = 0;
            char[] baseValue;
            Random random = null;
            StringBuilder resSb = new StringBuilder();
            baseNum = DateTime.Now.Ticks;
            random = new Random(((int)(((ulong)baseNum) & 0xffffffffL)) | ((int)(baseNum >> length)));

            for (int i = 0; i < length; i++)
            {
                baseValue = Guid.NewGuid().ToString().ToArray();
                foreach (char letter in baseValue)
                {
                    tempNum += Convert.ToInt32(letter);
                }

                if ((tempNum % 2) == 0)
                {
                    resSb.Append((char)(0x30 + ((ushort)(tempNum % 10))));
                }
                else
                {
                    resSb.Append((char)(0x41 + ((ushort)(tempNum % 0x1a))));
                }

            }

            return resSb.ToString();
        }

        /// <summary>  
        /// 根据GUID获取16位的唯一字符串  
        /// </summary>  
        /// <param name=\"guid\"></param>  
        /// <returns></returns>  
        public static string GuidTo16String()
        {
            long i = 1;
            foreach (byte b in Guid.NewGuid().ToByteArray())
                i *= ((int)b + 1);
            return string.Format("{0:x}", i - DateTime.Now.Ticks);
        }

        /// <summary>  
        /// 根据GUID获取19位的唯一数字序列  
        /// </summary>  
        /// <returns></returns>  
        public static long GuidToLongID()
        {
            byte[] buffer = Guid.NewGuid().ToByteArray();
            return BitConverter.ToInt64(buffer, 0);
        }

        /// <summary>  
        /// 生成22位唯一的数字 并发可用  
        /// </summary>  
        /// <returns></returns>  
        public static string GenerateUniqueID()
        {
            System.Threading.Thread.Sleep(1); //保证yyyyMMddHHmmssffff唯一  
            Random d = new Random(BitConverter.ToInt32(Guid.NewGuid().ToByteArray(), 0));
            string strUnique = DateTime.Now.ToString("yyyyMMddHHmmssffff") + d.Next(1000, 9999);
            return strUnique;
        }
    }
}
