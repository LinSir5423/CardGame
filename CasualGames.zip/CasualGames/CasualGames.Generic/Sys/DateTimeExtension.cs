﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    /// <summary>
    /// DateTime扩展类
    /// </summary>
    public static class DateTimeExtension
    {
        /// <summary>
        /// 获取本周的第一天（默认星期日为周的第一天）
        /// </summary>
        /// <param name="date">当前日期</param>
        /// <param name="isMonday">星期一为周的第一天</param>
        /// <returns></returns>
        public static DateTime GetWeekFirstDay(this DateTime date, bool isMonday = false)
        {
            int weeknow = (int)date.DayOfWeek;
            int daydiff = 0;
            if (isMonday)
            {
                daydiff = -1 * (weeknow - 1);
                if (weeknow == 0)
                    daydiff = (7 - 1) * (weeknow - 1);
            }
            else
            {
                daydiff = -1 * weeknow;
            }

            return date.AddDays(daydiff);
        }

        /// <summary>
        /// 获取本周的最后一天（默认星期六为周的最后一天）
        /// </summary>
        /// <param name="date">当前日期</param>
        /// <param name="isSaturday">星期六为周的最后一天</param>
        /// <returns></returns>
        public static DateTime GetWeekLastDay(this DateTime date, bool isSaturday = true)
        {
            int weeknow = (int)date.DayOfWeek;
            int daydiff = 0;
            if (isSaturday)
            {
                daydiff = 7 - weeknow - 1;
            }
            else
            {
                daydiff = weeknow == 0 ? 0 : 7 - weeknow;
            }
            return date.AddDays(daydiff);
        }

        /// <summary>
        /// 获取今天星期几
        /// </summary>
        /// <returns></returns>
        public static string GetWeek(this DateTime date)
        {
            string week = string.Empty;
            switch ((int)date.DayOfWeek)
            {
                case 0:
                    week = "星期日";
                    break;
                case 1:
                    week = "星期一";
                    break;
                case 2:
                    week = "星期二";
                    break;
                case 3:
                    week = "星期三";
                    break;
                case 4:
                    week = "星期四";
                    break;
                case 5:
                    week = "星期五";
                    break;
                default:
                    week = "星期六";
                    break;
            }
            return week;
        }

        /// <summary>
        /// 获取月的第一天
        /// </summary>
        /// <param name="date">当前日前</param>
        /// <returns></returns>
        public static DateTime GetMonthFirstDay(this DateTime date)
        {
            return date.AddDays(1 - (int)date.Day);
        }

        /// <summary>
        /// 获取月的最后一天
        /// </summary>
        /// <param name="date">当前日期</param>
        /// <returns></returns>
        public static DateTime GetMonthLastDay(this DateTime date)
        {
            return date.AddDays(1 - (int)date.Day).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// 获取指定时间距1970-1-1 00:00:00 的秒数
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static long TicksSecond(this DateTime date)
        {
            //DateTime startDate = new DateTime(1970, 1, 1);
            //TimeSpan timeSpan = date - startDate;
            //return DataHelper.ParseInt32(timeSpan.TotalSeconds);

            DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return (long)(date - startTime).TotalSeconds;
        }

        /// <summary>
        /// 获取指定时间距1970-1-1 00:00:00 的毫秒数
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static long TicksMillisecond(this DateTime date)
        {
            DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return (long)(date - startTime).TotalMilliseconds;
        }

        /// <summary>
        /// 将时间戳转换为时间
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static DateTime ConvertTimestamp(this string timestamp)
        {
            long lTime = 0;
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            try
            {
                for (int i = timestamp.Length; i < 17; i++)
                {
                    timestamp += '0';
                }

                lTime = long.Parse(timestamp);
            }
            catch
            {
                return new DateTime(1970, 1, 1);
            }
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /// <summary>
        /// 转换格式 1970-01-01 00:00:00
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string ToChinaString(this DateTime date)
        {
            return date.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}
