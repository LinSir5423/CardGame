﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public static class JsonHelper
    {
        #region 1.0 对象转JSON + public static string EntityToJson<T>(T entity)
        /// <summary>
        /// 对象转JSON（此处对象是某一个类的实例，而并非是说所有对象）
        /// </summary>
        /// <param name="obj">需要转换的对象</param>
        /// <returns>成功：返回转换后的json字符串   失败：抛异常</returns>
        public static string EntityToJson<T>(T entity)
        {
            JsonSerializerSettings jss = new JsonSerializerSettings();
            try
            {
                return JsonConvert.SerializeObject(entity, Formatting.Indented, jss);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
        #region 2.0 JSON转对象 +　public static T JsonToObject<T>(string jsonStr)
        /// <summary>
        /// JSON转对象（此处对象是某一个类的实例，而并非是说所有对象）
        /// </summary>
        /// <typeparam name="T">需要转换的对象类型</typeparam>
        /// <param name="jsonStr">需要转换的JSON字符串</param>
        /// <returns>成功：返回转换后的对象  失败：抛异常</returns>
        public static T JsonToObject<T>(string jsonStr)
        {
            JsonSerializerSettings jss = new JsonSerializerSettings();
            try
            {
                return JsonConvert.DeserializeObject<T>(jsonStr);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
        #region 3.0 数据表转JSON + public static string DataTableToJson(DataTable dt)
        /// <summary>
        /// 数据表转JSON
        /// </summary>
        /// <param name="dt">需要转换的数据表</param>
        /// <returns>成功：返回转换后的json字符串
        /// 失败：{"status":"Exception","msg":"传入的数据表为空！"}
        /// </returns>
        public static string DataTableToJson(DataTable dt)
        {
            if (dt == null || dt.Rows.Count <= 0)
            {
                return null;
            }
            else
            {
                List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
                foreach (DataRow dr in dt.Rows)
                {
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    foreach (DataColumn dc in dt.Columns)
                    {
                        dic.Add(dc.ColumnName, dr[dc.ColumnName]);
                    }
                    list.Add(dic);
                }
                return EntityToJson(list);
            }
        }
        #endregion
    }
}
