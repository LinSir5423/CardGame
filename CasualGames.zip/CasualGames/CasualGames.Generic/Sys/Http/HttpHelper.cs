﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys.Http
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpHelper
    {
        /// <summary>
        /// 登录接口
        /// </summary>
        public static string Login = "/monitor/login";

        /// <summary>
        /// 设置筹码
        /// </summary>
        public static string BeginInitAmount = "/monitor/beginInitAmount";

        /// <summary>
        /// 加减筹码和现金
        /// </summary>
        public static string SetAmount = "/monitor/setAmount";

        /// <summary>
        /// 录入数据、 补录
        /// </summary>
        public static string WriteRecord = "/monitor/writeRecord";

        /// <summary>
        /// 获取游戏路单
        /// </summary>
        public static string GetRoadList = "/monitor/getRoadList";

        /// <summary>
        /// 获取指定用户数据ByUsername
        /// </summary>
        public static string DetailUser = "/monitor/detailUser";

        /// <summary>
        /// 交接班核对数据
        /// </summary>
        public static string CheckData = "/monitor/checkData";

        /// <summary>
        /// 台面日结算
        /// </summary>
        public static string DaySettlement = "/monitor/daySettlement";

        /// <summary>
        /// 新靴
        /// </summary>
        public static string NewShoe = "/monitor/newShoe";

        /// <summary>
        /// 台桌投注统计
        /// </summary>
        public static string SearchGameRecord = "/monitor/searchGameRecord";

        #region 发送Http请求【支持https】
        /// <summary>
        /// 发送Http请求
        /// </summary>
        /// <param name="strUrl"></param>
        /// <param name="strEncoding"></param>
        /// <param name="strMethod"></param>
        /// <param name="strContentType"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public static string RequestHttp(
            string strUrl,
            string strData = null,
            string strContentType = "application/x-www-form-urlencoded",
            string strEncoding = "UTF-8",
            string strMethod = "POST",
            string strCookie = null,
            Dictionary<string, string> dicHeaders = null)
        {
            Byte[] byteDate = null;
            HttpWebRequest webRequest = null;
            string webResponseData = string.Empty;
            string originalWebResponseData = string.Empty;
            Encoding encoding = Encoding.GetEncoding(strEncoding);

            #region 创建请求对象
            if (strUrl.StartsWith("https", StringComparison.OrdinalIgnoreCase))
            {
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(CheckValidationResult);
                webRequest = WebRequest.Create(strUrl) as HttpWebRequest;
                webRequest.ProtocolVersion = HttpVersion.Version10;
            }
            else
            {
                webRequest = (HttpWebRequest)WebRequest.Create(new Uri(strUrl));
            }
            #endregion

            #region 设置请求头信息
            webRequest.Method = strMethod;
            webRequest.ContentType = strContentType;
            webRequest.Credentials = CredentialCache.DefaultCredentials;

            if (dicHeaders != null)
            {
                foreach (KeyValuePair<string, string> item in dicHeaders)
                {
                    webRequest.Headers.Add(item.Key, item.Value);
                }
            }

            if (!string.IsNullOrEmpty(strCookie))
            {
                webRequest.Headers.Add("Cookie", strCookie);
            }

            if (!string.IsNullOrEmpty(strData))
            {
                byteDate = encoding.GetBytes(strData);
                webRequest.ContentLength = byteDate.Length;
            }
            else
            {
                webRequest.ContentLength = 0;
            }
            #endregion

            #region 发送数据并获取返回数据
            try
            {
                if (byteDate != null)
                {
                    using (Stream outStream = webRequest.GetRequestStream())
                    {
                        outStream.Write(byteDate, 0, byteDate.Length);
                    }
                }

                HttpWebResponse webResponse = webRequest.GetResponse() as HttpWebResponse;
                webResponseData = new StreamReader(webResponse.GetResponseStream(), encoding).ReadToEnd();
                webResponse.Close();

                originalWebResponseData = webResponseData;
            }
            catch (WebException ex)
            {
                HttpWebResponse webResponse = (HttpWebResponse)ex.Response;
                Stream myResponseStream = webResponse.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
                webResponseData = myStreamReader.ReadToEnd();

                //webResponseData = JsonHelper.EntityToJson(new
                //{
                //    result = string.Empty,
                //    targetUrl = strUrl,
                //    success = false,
                //    error = new
                //    {
                //        code = -1,
                //        message = ex.Message,
                //    },
                //    unAuthorizedRequest = false
                //});

                int code = -1;
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    var response = ex.Response as HttpWebResponse;
                    if (response != null)
                    {
                        code = (int)response.StatusCode;
                    }
                }

                //Log.Info("HTTP请求异常：" + code);
            }
            catch (Exception ex)
            {
                webResponseData = JsonHelper.EntityToJson(new
                {
                    result = string.Empty,
                    targetUrl = strUrl,
                    success = false,
                    error = new
                    {
                        code = -1,
                        message = ex.Message,
                    },
                    unAuthorizedRequest = false
                });
            }
            #endregion

            //StringBuilder logMsgSb = new StringBuilder();
            //logMsgSb.Append("HTTP请求日志记录" + "\r");
            //logMsgSb.Append("ResultUrl：" + strUrl + "\r");
            //logMsgSb.Append("ResultData：" + strData + "\r");
            //logMsgSb.Append("OriginalResponseData：" + originalWebResponseData + "\r");
            //logMsgSb.Append("ResponseData：" + webResponseData + "\r");
            //Log.Info(logMsgSb.ToString());

            return webResponseData;
        }

        private static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true; //总是接受   
        }
        #endregion
    }
}
