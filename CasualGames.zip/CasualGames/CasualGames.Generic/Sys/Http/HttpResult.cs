﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys.Http
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpResult<T>
    {
        public T Data { get; set; }
        public string Message { get; set; }
    }
}
