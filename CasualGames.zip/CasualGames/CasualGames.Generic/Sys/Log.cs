﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    /// <summary>
    /// Log4Net日志帮助类
    /// </summary>
    public class Log
    {
        private static string log4netConfigPath = Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Commons\\Configs\\log4net.config");

        /// <summary>
        /// 普通日志记录器
        /// </summary>
        private static ILog loginfo = GetLogger("loginfo", log4netConfigPath);
        /// <summary>
        /// 异常日志记录器
        /// </summary>
        private static ILog logerror = GetLogger("logerror", log4netConfigPath);
        /// <summary>
        /// 请求响应日志记录器
        /// </summary>
        private static ILog logmonitor = GetLogger("logmonitor", log4netConfigPath);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="loggerName"></param>
        /// <param name="configPath"></param>
        /// <returns></returns>
        private static ILog GetLogger(string loggerName, string configPath)
        {
            ILog log = null;
            if (!string.IsNullOrEmpty(configPath))
            {
                log4net.Repository.ILoggerRepository repository = LogManager.CreateRepository(loggerName);
                log4net.Config.XmlConfigurator.Configure(repository, new FileInfo(configPath));
                log = log4net.LogManager.GetLogger(repository.Name, loggerName);
            }
            return log;
        }

        #region 异常日志记录
        /// <summary>
        /// 记录已捕获的异常信息
        /// </summary>
        /// <param name="lastErr"></param>
        public static void CatchException(Exception lastErr, string errorMsg = null)
        {
            Error(errorMsg, lastErr, true);
        }

        /// <summary>
        /// 记录没有捕获的异常信息
        /// </summary>
        /// <param name="lastErr"></param>
        public static void NoCatchException(Exception lastErr, string errorMsg = null)
        {
            Error(errorMsg, lastErr, false);
        }

        /// <summary>
        /// 记录异常日志
        /// </summary>
        /// <param name="ErrorMsg"></param>
        /// <param name="ex"></param>
        private static void Error(string errorMsg, Exception lastErr = null, bool isCatch = false)
        {
            StringBuilder error = new StringBuilder();
            error.AppendLine("是否捕获:" + (isCatch ? "是" : "否"));
            error.AppendLine("发生时间:" + System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ffff"));

            if (!string.IsNullOrEmpty(errorMsg))
            {
                error.AppendLine("描述信息: " + errorMsg);
            }

            if (lastErr != null)
            {
                Exception objErr = lastErr.GetBaseException();
                error.AppendLine("异常信息: " + Regex.Replace(objErr.Message, @"\n\s*\n", "\r\n"));
                error.AppendLine("引发异常方法: " + objErr.TargetSite);
                AppendInnerException(error, objErr.InnerException, 1);
                error.AppendLine("错误源:" + objErr.Source);
                error.AppendLine("堆栈信息:" + "\n" + Regex.Replace(objErr.StackTrace, @"\n\s*\n", "\r\n").Replace("<", "&lt;").Replace(">", "&gt;"));
            }
            try
            {
                logerror.Error(error.ToString());
            }
            catch { }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="error"></param>
        /// <param name="objErr"></param>
        /// <param name="i"></param>
        private static void AppendInnerException(StringBuilder error, Exception objErr, int i)
        {
            if (objErr != null)
            {
                error.AppendFormat("内部异常信息{0}: {1}\n", i, objErr.Message);
                if (objErr.InnerException != null)
                    AppendInnerException(error, objErr.InnerException, i + 1);
            }
        }
        #endregion

        #region 信息日志记录
        /// <summary>
        /// 记录消息日志
        /// </summary>
        /// <param name="Msg"></param>
        public static void Info(string Msg)
        {
            try
            {
                loginfo.Info(Msg.Replace("\r\n", "").Replace("\n", ""));
            }
            catch { }
        }
        #endregion

        #region 请求响应日志记录
        /// <summary>
        /// 记录监控日志
        /// </summary>
        /// <param name="Msg"></param>
        public static void Monitor(string Msg)
        {
            try
            {
                logmonitor.Info(Msg);
            }
            catch { }
        }
        #endregion
    }
}
