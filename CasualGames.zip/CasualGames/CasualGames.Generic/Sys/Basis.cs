﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    public class Basis
    {
        /// <summary>
        /// 配置文件
        /// </summary>
        public const string INI_CFG = "user.ini";

        /// <summary>
        /// 密码加密串
        /// </summary>
        public static readonly string AesSecretKey = "S8r0Gn$I$H#D#x*8Ub1wRLsL3uxmQFz3";

        /// <summary>
        /// 接口服务器地址
        /// </summary>
        public static string CardGamesServerAddress = "";

        /// <summary>
        /// 是否授权
        /// </summary>
        public static bool IsAuthorization = true;
    }
}
