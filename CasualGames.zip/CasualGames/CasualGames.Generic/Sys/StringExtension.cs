﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Generic.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public static class StringExtension
    {
        #region 判断部分
        /// <summary>
        /// 判断是否包含子串
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static bool IsContains(this string text, string value)
        {
            if (value == null)
            {
                return false;
            }
            if (value.Length == 0) //string.Empty
            {
                return text.Length == value.Length;
            }
            return text.Contains(value);
        }
        #endregion

        #region 加密部分
        /// <summary>
        /// 获取字符串的MD5哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static string ToMD5Hash(this string text, string encoding = "utf-8")
        {
            MD5CryptoServiceProvider md5Hasher = new MD5CryptoServiceProvider();
            return text.ToCryptHash(md5Hasher, encoding);
        }

        /// <summary>
        /// 获取字符串的MD5码
        /// </summary>
        /// <param name="text"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string ToMD5(this string text, string encoding = "utf-8")
        {
            string pwd = string.Empty;
            MD5 md5 = MD5.Create();//实例化一个md5对像
            // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(text));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                pwd = pwd + s[i].ToString("x2");

            }
            return pwd;
        }

        /// <summary>
        /// 获取字符串的SHA1哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static string ToSha1Hash(this string text, string encoding = "utf-8")
        {
            SHA1CryptoServiceProvider sha1Hasher = new SHA1CryptoServiceProvider();
            return text.ToCryptHash(sha1Hasher, encoding);
        }

        /// <summary>
        /// 获取字符串的SHA256哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static string ToSha256Hash(this string text, string encoding = "utf-8")
        {
            SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();
            return text.ToCryptHash(sha256, encoding);
        }

        /// <summary>
        /// 获取字符串的SHA384哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static string ToSha384Hash(this string text, string encoding = "utf-8")
        {
            SHA384CryptoServiceProvider sha256 = new SHA384CryptoServiceProvider();
            return text.ToCryptHash(sha256, encoding);
        }

        /// <summary>
        /// 获取字符串的SHA512哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="encoding">编码方式</param>
        /// <returns></returns>
        public static string ToSha512Hash(this string text, string encoding = "utf-8")
        {
            SHA512CryptoServiceProvider sha256 = new SHA512CryptoServiceProvider();
            return text.ToCryptHash(sha256, encoding);
        }

        /// <summary>
        /// 获取字符串的HMACMD5哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string ToHmacMd5(this string text, string key, string encoding = "utf-8")
        {
            HMACMD5 md5 = new HMACMD5(Encoding.UTF8.GetBytes(key));
            return text.ToCryptHash(md5, encoding);
        }

        /// <summary>
        /// 获取字符串的HMACSHA1哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string ToHmacSha1(this string text, string key, string encoding = "utf-8")
        {
            HMACSHA1 sha1 = new HMACSHA1(Encoding.UTF8.GetBytes(key));
            return text.ToCryptHash(sha1, encoding);
        }

        /// <summary>
        /// 获取字符串的HMACSHA256哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string ToHmacSha256(this string text, string key, string encoding = "utf-8")
        {
            HMACSHA256 sha256 = new HMACSHA256(Encoding.UTF8.GetBytes(key));
            return text.ToCryptHash(sha256, encoding);
        }

        /// <summary>
        /// 获取字符串的HMACSHA384哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string ToHmacSha384(this string text, string key, string encoding = "utf-8")
        {
            HMACSHA384 sha384 = new HMACSHA384(Encoding.UTF8.GetBytes(key));
            return text.ToCryptHash(sha384, encoding);
        }

        /// <summary>
        /// 获取字符串的HMACSHA512哈希码
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string ToHmacSha512(this string text, string key, string encoding = "utf-8")
        {
            HMACSHA512 sha512 = new HMACSHA512(Encoding.UTF8.GetBytes(key));
            return text.ToCryptHash(sha512, encoding);
        }


        private static string ToCryptHash(this string text, HashAlgorithm hashAlgorithm, string encoding = "utf-8")
        {
            Encoding enc = Encoding.GetEncoding(encoding);
            byte[] data = hashAlgorithm.ComputeHash(enc.GetBytes(text));
            StringBuilder sBuilder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }
        #endregion

        #region 获取部分
        /// <summary>
        /// 获取字符串拼音首字母
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string SpellCode(this string text)
        {
            if (string.IsNullOrEmpty(text.Trim()))
            {
                return "?";
            }
            long iCnChar;
            string cnChar = text.Trim().Substring(0, 1);
            byte[] ZW = System.Text.Encoding.Default.GetBytes(cnChar);

            //如果是字母，则直接返回首字母
            if (ZW.Length == 1)
            {
                return cnChar.ToUpper();
            }
            else
            {
                int i1 = (short)(ZW[0]);
                int i2 = (short)(ZW[1]);
                iCnChar = i1 * 256 + i2;
            }

            if ((iCnChar >= 45217) && (iCnChar <= 45252)) { return "A"; }
            else if ((iCnChar >= 45253) && (iCnChar <= 45760)) { return "B"; }
            else if ((iCnChar >= 45761) && (iCnChar <= 46317)) { return "C"; }
            else if ((iCnChar >= 46318) && (iCnChar <= 46825)) { return "D"; }
            else if ((iCnChar >= 46826) && (iCnChar <= 47009)) { return "E"; }
            else if ((iCnChar >= 47010) && (iCnChar <= 47296)) { return "F"; }
            else if ((iCnChar >= 47297) && (iCnChar <= 47613)) { return "G"; }
            else if ((iCnChar >= 47614) && (iCnChar <= 48118)) { return "H"; }
            else if ((iCnChar >= 48119) && (iCnChar <= 49061)) { return "J"; }
            else if ((iCnChar >= 49062) && (iCnChar <= 49323)) { return "K"; }
            else if ((iCnChar >= 49324) && (iCnChar <= 49895)) { return "L"; }
            else if ((iCnChar >= 49896) && (iCnChar <= 50370)) { return "M"; }
            else if ((iCnChar >= 50371) && (iCnChar <= 50613)) { return "N"; }
            else if ((iCnChar >= 50614) && (iCnChar <= 50621)) { return "O"; }
            else if ((iCnChar >= 50622) && (iCnChar <= 50905)) { return "P"; }
            else if ((iCnChar >= 50906) && (iCnChar <= 51386)) { return "Q"; }
            else if ((iCnChar >= 51387) && (iCnChar <= 51445)) { return "R"; }
            else if ((iCnChar >= 51446) && (iCnChar <= 52217)) { return "S"; }
            else if ((iCnChar >= 52218) && (iCnChar <= 52697)) { return "T"; }
            else if ((iCnChar >= 52698) && (iCnChar <= 52979)) { return "W"; }
            else if ((iCnChar >= 52980) && (iCnChar <= 53640)) { return "X"; }
            else if ((iCnChar >= 53689) && (iCnChar <= 54480)) { return "Y"; }
            else if ((iCnChar >= 54481) && (iCnChar <= 55289)) { return "Z"; }
            else return ("?");

        }

        /// <summary>
        /// 相对路径转绝对路径
        /// </summary>
        /// <param name="devPath"></param>
        /// <returns></returns>
        public static string ToAbsolutePath(this string relativePath)
        {
            if (relativePath.IndexOf(":") < 0)
            {
                //System.Web.HttpContext.Current.Server.MapPath(relativePath);
                relativePath = AppDomain.CurrentDomain.BaseDirectory + relativePath;
            }

            return relativePath;
        }

        /// <summary>
        /// 兼容不同操作系统
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        //public static string AutoCompatibleOsFolderPath(this string path)
        //{
        //    if (string.IsNullOrEmpty(path)) return path;

        //    path = Basis.IsUnix ? path.Replace('\\', '/') : path.Replace('/', '\\');//兼容OS
        //    path = path.Replace(@"//", @"/");//兼容多个//
        //    path = path.Replace(@"\\", @"\");//兼容多个\\

        //    return path;
        //}
        #endregion
    }
}
