﻿

namespace CasualGames.Generic.Sys.AesHelper
{
    /// <summary>
    /// AES密钥大小枚举
    /// </summary>
    public enum AesKeySize
    {
        /// <summary>
        /// 128位
        /// </summary>
        Value_128 = 128,

        /// <summary>
        /// 192位
        /// </summary>
        Value_192 = 192,

        /// <summary>
        /// 256位
        /// </summary>
        Value_256 = 256
    }
}
