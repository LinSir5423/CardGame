﻿
namespace CasualGames.Generic.Sys.AesHelper
{
    /// <summary>
    /// AES数据块大小枚举
    /// </summary>
    public enum AesBlockSize
    {
        /// <summary>
        /// 128位
        /// </summary>
        Value_128 = 128,

        /// <summary>
        /// 192位
        /// </summary>
        Value_192 = 192,

        /// <summary>
        /// 256位
        /// </summary>
        Value_256 = 256
    }
}
