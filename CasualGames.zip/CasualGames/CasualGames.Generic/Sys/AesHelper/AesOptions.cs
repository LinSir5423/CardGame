﻿using System.Security.Cryptography;

namespace CasualGames.Generic.Sys.AesHelper
{
    /// <summary>
    /// Aes加解密配置对象
    /// </summary>
    public class AesOptions
    {
        /// <summary>
        /// 明文或密文
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 秘钥
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 向量
        /// </summary>
        public string Vector { get; set; }

        /// <summary>
        /// 数据块大小
        /// </summary>
        public AesBlockSize BlockSize { get; set; }

        /// <summary>
        /// 秘钥大小
        /// </summary>
        public AesKeySize KeySize { get; set; }

        /// <summary>
        /// 加密模式
        /// </summary>
        public CipherMode Mode { get; set; }

        /// <summary>
        /// 填充模式
        /// </summary>
        public PaddingMode Padding { get; set; }
    }
}
