﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CasualGames.Generic.Sys.AesHelper
{
    public static class AesHelper
    {
        #region 加密
        /// <summary>
        /// AES加密
        /// 输入一个普通的文本，以加密后的Base64编码输出
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <returns></returns>
        public static string Encrypt(string text, string key)
        {
            return AesHelper.Encrypt(new AesOptions() { Text = text, Key = key });
        }

        /// <summary>
        /// AES加密
        /// 输入一个普通的文本，以加密后的Base64编码输出
        /// </summary>
        /// <param name="options">AES配置对象</param>
        /// <returns>加密后的文本Base64编码输出</returns>
        public static string Encrypt(AesOptions options)
        {
            if (String.IsNullOrEmpty(options.Key))
            {
                throw new ArgumentNullException("密钥为空异常");
            }
            if (options.Mode > 0 && options.Mode != CipherMode.ECB && String.IsNullOrEmpty(options.Vector))
            {
                throw new ArgumentNullException("ECB加密模式下，未填写向量");
            }

            byte[] encrypted;
            byte[] textArr = Encoding.UTF8.GetBytes(options.Text);
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                #region 加密参数设置
                rijAlg.Key = Encoding.UTF8.GetBytes(options.Key.PadRight(32, '0'));
                if (!String.IsNullOrEmpty(options.Vector))
                {
                    //如果有设置向量，只能设置为16字节
                    byte[] tmpChat = Encoding.UTF8.GetBytes(options.Vector.PadRight(16, '0'));
                    byte[] tmpByte = new byte[16];
                    try
                    {
                        Array.Copy(tmpChat, tmpByte, 16);
                        rijAlg.IV = tmpByte;
                    }
                    catch (Exception ex)
                    {
                        //Log.WriteCatchEx(ex);
                    }
                }
                if (options.BlockSize > 0)
                {
                    rijAlg.BlockSize = (int)options.BlockSize;
                }
                if (options.KeySize > 0)
                {
                    rijAlg.KeySize = (int)options.KeySize;
                }
                if (options.Mode > 0)
                {
                    rijAlg.Mode = options.Mode;
                }
                else
                {
                    rijAlg.Mode = CipherMode.ECB;
                }
                if (options.Padding > 0)
                {
                    rijAlg.Padding = options.Padding;
                }
                #endregion

                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (CryptoStream cStream = new CryptoStream(mStream, encryptor, CryptoStreamMode.Write))
                    {
                        cStream.Write(textArr, 0, textArr.Length);
                        cStream.FlushFinalBlock();
                        encrypted = mStream.ToArray();
                    }
                }

            }

            return Convert.ToBase64String(encrypted);
        }
        #endregion

        #region 解密
        /// <summary>
        /// AES解密
        /// 输入的是一个Base64编码过的AES加密串，输出是UTF-8编码的普通文本
        /// </summary>
        /// <param name="text">文本</param>
        /// <param name="key">密钥</param>
        /// <returns></returns>
        public static string Decrypt(string text, string key)
        {
            return AesHelper.Decrypt(new AesOptions() { Text = text, Key = key });
        }

        /// <summary>
        /// AES解密
        /// 输入的是一个Base64编码过的AES加密串，输出是UTF-8编码的普通文本
        /// </summary>
        /// <param name="options">AES配置对象</param>
        /// <returns>UTF-8编码的普通文本</returns>
        public static string Decrypt(AesOptions options)
        {
            if (String.IsNullOrEmpty(options.Key))
            {
                throw new ArgumentNullException("密钥为空异常");
            }
            if (options.Mode > 0 && options.Mode != CipherMode.ECB && String.IsNullOrEmpty(options.Vector))
            {
                throw new ArgumentNullException("ECB加密模式下，未填写向量");
            }
            string plaintext = string.Empty;
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                #region 加密参数设置
                rijAlg.Key = Encoding.UTF8.GetBytes(options.Key.PadRight(32, '0'));
                if (!String.IsNullOrEmpty(options.Vector))
                {
                    //如果有设置向量，只能设置为16字节
                    byte[] tmpChat = Encoding.UTF8.GetBytes(options.Vector.PadRight(16, '0'));
                    byte[] tmpByte = new byte[16];
                    try
                    {
                        Array.Copy(tmpChat, tmpByte, 16);
                        rijAlg.IV = tmpByte;
                    }
                    catch (Exception ex)
                    {
                        //Log.WriteCatchEx(ex);
                    }
                }
                if (options.BlockSize > 0)
                {
                    rijAlg.BlockSize = (int)options.BlockSize;
                }
                if (options.KeySize > 0)
                {
                    rijAlg.KeySize = (int)options.KeySize;
                }
                if (options.Mode > 0)
                {
                    rijAlg.Mode = options.Mode;
                }
                else
                {
                    rijAlg.Mode = CipherMode.ECB;
                }
                if (options.Padding > 0)
                {
                    rijAlg.Padding = options.Padding;
                }
                #endregion

                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                byte[] text = new byte[] { };
                try
                {
                    text = Convert.FromBase64String(options.Text);
                }
                catch (Exception ex)
                {
                    //Log.WriteCatchEx(ex);
                }
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (CryptoStream cStream = new CryptoStream(mStream, decryptor, CryptoStreamMode.Write))
                    {
                        cStream.Write(text, 0, text.Length);
                        cStream.FlushFinalBlock();
                        plaintext = Encoding.UTF8.GetString(mStream.ToArray());
                    }
                }

            }
            return plaintext;
        }
        #endregion
    }
}
