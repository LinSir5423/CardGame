﻿using CasualGames.Generic.Sys;
using CasualGames.Model.ViewDatas;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CasualGames.Domain
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// 注单信息
        /// </summary>
        public BaccaratWagerInfo WagerInfo;

        /// <summary>
        /// 露珠信息
        /// </summary>
        public BaccaratDewdropInfo DewdropInfo;

        public MainWindow()
        {
            InitializeComponent();
            FullScreenHelper.ExitFullscreen(this);

            WagerInfo = new BaccaratWagerInfo();
            DewdropInfo = new BaccaratDewdropInfo();

            SysHelper.InitBaccaratWagerInfo(WagerInfo.GridData);
            this.BoWagerInfoData.DataContext = WagerInfo;
            this.DgWagerInfoDataGrid.ItemsSource = WagerInfo.GridData;

            //string strDewdrop = "c,a,a,a,c,c,e,a,i,c,c,e,b,e,c,c,a,a,e,a,c,c,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,a,e,c,a,a,e,a,e,e,e,e,a,e,a,i,a,e,e,b,e,a,a,a,a,e,a,e,e,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,e,e,e,a,e,i,e,e,c";
            //SysHelper.ConvertBaccaratDewdropInfo(strDewdrop, DewdropInfo.GridData);
            //this.BoWagerInfoData.DataContext = DewdropInfo;
            //this.DgDewdropInfoDataGrid.ItemsSource = DewdropInfo.GridData;

            for (int i = 0; i < 10; i++)
            {
                DewdropInfo.GridData.Add(new BaccaratDewdropInfoGrid()
                {
                    GridData01 = "a",
                    GridData02 = "a",
                    GridData03 = "a",
                    GridData04 = "a",
                    GridData05 = "a",
                    GridData06 = "a",
                    GridData07 = "a",
                    GridData08 = "a",
                    GridData09 = "a",
                    GridData10 = "a",

                    GridData11 = "a",
                    GridData12 = "a",
                    GridData13 = "a",
                    GridData14 = "a",
                    GridData15 = "a",
                    GridData16 = "a",
                    GridData17 = "a",
                    GridData18 = "a",
                    GridData19 = "a",
                    GridData20 = "a",

                    GridData21 = "a",
                    GridData22 = "a",
                    GridData23 = "a",
                    GridData24 = "a",
                    GridData25 = "a",
                });
            }
            this.BoWagerInfoData.DataContext = DewdropInfo;
            this.DgDewdropInfoDataGrid.ItemsSource = DewdropInfo.GridData;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.GetCurrentProcess().Kill();
            System.Windows.Application.Current.Shutdown();
        }

        /// <summary>
        /// 增加一行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddRow_Click(object sender, RoutedEventArgs e)
        {
            int index = 0;
            if (this.WagerInfo.GridData.Count <= 0)
            {
                index = 0;
            }
            else
            {
                index = this.WagerInfo.GridData.OrderByDescending(s => s.Index).FirstOrDefault().Index;
            }

            this.WagerInfo.GridData.Add(new BaccaratWagerInfoGrid()
            {
                Index = ++index,
                HasData = false,
            });

            // 数据大于8条才会有滚动条
            if (this.WagerInfo.GridData.Count > 8)
            {
                this.DgWagerInfoDataGrid.SelectedIndex = this.DgWagerInfoDataGrid.Items.Count - 1;
                this.DgWagerInfoDataGrid.ScrollIntoView(this.DgWagerInfoDataGrid.SelectedItem);
            }
        }

        /// <summary>
        /// 减少一行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.WagerInfo.GridData == null || this.WagerInfo.GridData.Count <= 0)
            {
                return;
            }
            var maxIndex = this.WagerInfo.GridData.OrderByDescending(s => s.Index).FirstOrDefault().Index;
            this.WagerInfo.GridData.RemoveAt(--maxIndex);

            // 数据大于8条才会有滚动条
            if (this.WagerInfo.GridData.Count > 8)
            {
                this.DgWagerInfoDataGrid.SelectedIndex = this.DgWagerInfoDataGrid.Items.Count - 1;
                this.DgWagerInfoDataGrid.ScrollIntoView(this.DgWagerInfoDataGrid.SelectedItem);
            }
        }

        /// <summary>
        /// 清除数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClearDatra_Click(object sender, RoutedEventArgs e)
        {
            var rowData = this.DgWagerInfoDataGrid.SelectedItem as BaccaratWagerInfoGrid;

            var selectData = this.WagerInfo.GridData.FirstOrDefault(s => s.Index == rowData.Index);
            if (selectData != null)
            {
                selectData.HasData = false;
                selectData.UserName = string.Empty;
                selectData.UserId = 0;
                selectData.Zhuang = 0;
                selectData.Xian = 0;
                selectData.He = 0;
                selectData.ZhuangDui = 0;
                selectData.XianDui = 0;
                selectData.CashType = false;
            }
        }

        /// <summary>
        /// 注单双击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgWagerInfoDataGrid_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //var rowData = (this.DgWagerInfoDataGrid.SelectedItem as DataGridRow).Item as WagerInfo;
        }
    }
}
