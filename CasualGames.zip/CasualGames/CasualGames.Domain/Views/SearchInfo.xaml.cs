﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using CasualGames.Model.ViewDatas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// SearchInfo.xaml 的交互逻辑
    /// </summary>
    public partial class SearchInfo : Window
    {

        /// <summary>
        /// 数据
        /// </summary>
        public GameRecordInfo GameRecordInfo;

        public SearchInfo()
        {
            InitializeComponent();
            this.DtpEndDate.SelectedDateTime = DateTime.Now;
            //this.DtpStartDate.SelectedDateTime = DateTime.Now.AddDays(-1);
            this.TbChang.Text = Loginer.Chang.ToString();

            FullScreenHelper.ExitFullscreen(this);
            GameRecordInfo = new GameRecordInfo();
            GameRecordInfo.Data = new List<GameRecordInfoGrid>();

            this.DataContext = GameRecordInfo;
            this.DgInfoDataGrid.ItemsSource = this.GameRecordInfo.Data;
        }

        #region 窗体事件
        /// <summary>
        /// 窗体关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 窗体移动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Source is StackPanel)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        private void LoadData()
        {
            GameRecordInfo = new GameRecordInfo();
            GameRecordInfo.Data = new List<GameRecordInfoGrid>();

            int chang = 0;
            int ci = 0;

            if (!string.IsNullOrEmpty(this.TbChang.Text))
            {
                try
                {
                    chang = int.Parse(this.TbChang.Text);
                }
                catch
                {
                    SysMessage.ShowMessage("请输入正确的场号【为整数】");
                }
            }

            if (!string.IsNullOrEmpty(this.TbCi.Text))
            {
                try
                {
                    ci = int.Parse(this.TbCi.Text);
                }
                catch
                {
                    SysMessage.ShowMessage("请输入正确的次号【为整数】");
                }
            }

            var hander = SysMessage.Loading();
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.SearchGameRecord, JsonHelper.EntityToJson(new
            {
                game_type = Loginer.GameType,
                game_id = Loginer.Id,
                chang = chang,
                ci = ci,
                username = this.TbUserName.Text.Trim(),
                start_time = this.DtpStartDate.SelectedDateTime.ToString("yyyy-MM-dd") + " 00:00:00",
                end_time = this.DtpEndDate.SelectedDateTime.ToString("yyyy-MM-dd") + " 23:59:59"

            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });
            hander.Close();

            if (!string.IsNullOrEmpty(resStringData))
            {
                var resObjData = JsonHelper.JsonToObject<HttpResult<GameRecordInfo>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    if (resObjData.Data != null && resObjData.Data.Data != null)
                    {
                        GameRecordInfo = resObjData.Data;
                    }
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }

            this.DataContext = GameRecordInfo;
            this.DgInfoDataGrid.ItemsSource = this.GameRecordInfo.Data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
