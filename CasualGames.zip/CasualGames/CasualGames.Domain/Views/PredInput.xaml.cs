﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using CasualGames.Model.HttpResult;
using CasualGames.Model.ViewDatas.Pred;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// PredInput.xaml 的交互逻辑
    /// </summary>
    public partial class PredInput : Window
    {
        /// <summary>
        /// 父窗体传递的参数
        /// </summary>
        public PredWagerInfoGrid PredWagerInfoGrid;

        /// <summary>
        /// 页面自己绑定的数据
        /// </summary>
        public PagePredWagerInfoGrid PageWagerInfo;

        /// <summary>
        /// 回调委托
        /// </summary>
        public CallBackDelegate CallBack = null;

        public PredInput()
        {
            InitializeComponent();
            PredWagerInfoGrid = new PredWagerInfoGrid();
            PageWagerInfo = new PagePredWagerInfoGrid();

            this.DataContext = PageWagerInfo;
        }

        #region 窗体事件
        /// <summary>
        /// 窗体关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
            CallBack?.Invoke();
        }

        /// <summary>
        /// 窗体移动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Source is StackPanel)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }
        #endregion

        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            if (PageWagerInfo.UserId <= 0)
            {
                SysMessage.ShowMessage("无效数据，请输入账号查询用户信息");
                return;
            }

            PredWagerInfoGrid.UserName = PageWagerInfo.UserName;
            PredWagerInfoGrid.UserId = PageWagerInfo.UserId;
            PredWagerInfoGrid.Long = PageWagerInfo.Long;
            PredWagerInfoGrid.Hu = PageWagerInfo.Hu;
            PredWagerInfoGrid.He = PageWagerInfo.He;
            PredWagerInfoGrid.CashType = PageWagerInfo.CashChecked;
            PredWagerInfoGrid.HasData = true;
            this.Close();
            CallBack?.Invoke();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            PageWagerInfo.UserName = this.PredWagerInfoGrid.UserName;
            PageWagerInfo.UserId = this.PredWagerInfoGrid.UserId;
            PageWagerInfo.Long = this.PredWagerInfoGrid.Long;
            PageWagerInfo.Hu = this.PredWagerInfoGrid.Hu;
            PageWagerInfo.He = this.PredWagerInfoGrid.He;
            PageWagerInfo.CashChecked = this.PredWagerInfoGrid.CashType;
            PageWagerInfo.ChipChecked = !this.PredWagerInfoGrid.CashType;
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            CallBack?.Invoke();
        }

        /// <summary>
        /// 账号文本框失去焦点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TbUserName_LostFocus(object sender, RoutedEventArgs e)
        {
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.DetailUser, JsonHelper.EntityToJson(new
            {
                username = this.TbUserName.Text.Trim()
            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                if (resObjData.Data.user_id <= 0)
                {
                    SysMessage.ShowNotification("未找到用户数据");
                }

                PageWagerInfo.UserId = resObjData.Data.user_id;
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }
    }
}
