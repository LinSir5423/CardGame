﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using CasualGames.Model.Enums;
using CasualGames.Model.HttpResult;
using CasualGames.Model.ViewDatas;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// BaccaratMain.xaml 的交互逻辑
    /// </summary>
    public partial class BaccaratMain : Window
    {
        /// <summary>
        /// 游戏的基础信息
        /// </summary>
        public GameBaseInfo GameBaseInfo;

        /// <summary>
        /// 注单信息
        /// </summary>
        public BaccaratWagerInfo WagerInfo;

        /// <summary>
        /// 露珠信息
        /// </summary>
        public BaccaratDewdropInfo DewdropInfo;

        /// <summary>
        /// 定时器
        /// </summary>
        private DispatcherTimer ShowTimer;
        public BaccaratMain()
        {
            InitializeComponent();
            FullScreenHelper.ExitFullscreen(this);

            GameBaseInfo = new GameBaseInfo() { ShowTime = DateTime.Now.ToString("yyyy-MM-dd HH;mm:ss") };
            WagerInfo = new BaccaratWagerInfo();
            DewdropInfo = new BaccaratDewdropInfo();

            this.DataContext = GameBaseInfo;

            SysHelper.InitBaccaratWagerInfo(WagerInfo.GridData);
            this.BoWagerInfoData.DataContext = WagerInfo;
            this.DgWagerInfoDataGrid.ItemsSource = WagerInfo.GridData;

            //string strDewdrop = "c,a,a,a,c,c,e,a,i,c,c,e,b,e,c,c,a,a,e,a,c,c,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,a,e,c,a,a,e,a,e,e,e,e,a,e,a,i,a,e,e,b,e,a,a,a,a,e,a,e,e,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,e,e,e,e,e,e,e,e,e,a,e,i,e,e,c,i,a,e,c,a,a,e,a,e,e,e,e,a,e,a,i,a,e,e,b,e,a,a,a,a,e,a,e,e,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,e,e,e,a,e,i,e,e,c";
            SysHelper.ConvertBaccaratDewdropInfo(Loginer.RoadList, DewdropInfo.GridData);
            this.BoWagerInfoData.DataContext = DewdropInfo;
            this.DgDewdropInfoDataGrid.ItemsSource = DewdropInfo.GridData;

            // 时间定时器
            ShowTimer = new System.Windows.Threading.DispatcherTimer();
            ShowTimer.Tick += new EventHandler(ShowCurTimer);
            ShowTimer.Interval = new TimeSpan(0, 0, 0, 1, 0);
            ShowTimer.Start();
        }

        #region 其他方法
        /// <summary>
        /// 当前时间处理【含自动刷新AccessToken】
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowCurTimer(object sender, EventArgs e)
        {
            this.TbDateTime.Content = DateTime.Now.ToString("yyyy年MM月dd日 HH:mm:ss");
        }
        #endregion

        /// <summary>
        /// 关闭窗体
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (SysMessage.ShowMessage("您确定要【退出系统】吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                Process.GetCurrentProcess().Kill();
                System.Windows.Application.Current.Shutdown();
            }
        }

        /// <summary>
        /// 增加一行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddRow_Click(object sender, RoutedEventArgs e)
        {
            int index = 0;
            if (this.WagerInfo.GridData.Count <= 0)
            {
                index = 0;
            }
            else
            {
                index = this.WagerInfo.GridData.OrderByDescending(s => s.Index).FirstOrDefault().Index;
            }

            this.WagerInfo.GridData.Add(new BaccaratWagerInfoGrid()
            {
                Index = ++index,
                HasData = false,
                ChipChecked = true
            });

            // 数据大于8条才会有滚动条
            if (this.WagerInfo.GridData.Count > 8)
            {
                this.DgWagerInfoDataGrid.SelectedIndex = this.DgWagerInfoDataGrid.Items.Count - 1;
                this.DgWagerInfoDataGrid.ScrollIntoView(this.DgWagerInfoDataGrid.SelectedItem);
            }

            StatisticsWagerInfo();
        }

        /// <summary>
        /// 减少一行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.WagerInfo.GridData == null || this.WagerInfo.GridData.Count <= 0)
            {
                return;
            }
            var maxIndex = this.WagerInfo.GridData.OrderByDescending(s => s.Index).FirstOrDefault().Index;
            this.WagerInfo.GridData.RemoveAt(--maxIndex);

            // 数据大于8条才会有滚动条
            if (this.WagerInfo.GridData.Count > 8)
            {
                this.DgWagerInfoDataGrid.SelectedIndex = this.DgWagerInfoDataGrid.Items.Count - 1;
                this.DgWagerInfoDataGrid.ScrollIntoView(this.DgWagerInfoDataGrid.SelectedItem);
            }

            StatisticsWagerInfo();
        }

        /// <summary>
        /// 清除数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClearDatra_Click(object sender, RoutedEventArgs e)
        {
            var rowData = this.DgWagerInfoDataGrid.SelectedItem as BaccaratWagerInfoGrid;

            var selectData = this.WagerInfo.GridData.FirstOrDefault(s => s.Index == rowData.Index);
            if (selectData != null)
            {
                selectData.HasData = false;
                selectData.UserName = string.Empty;
                selectData.UserId = 0;
                selectData.Zhuang = 0;
                selectData.Xian = 0;
                selectData.He = 0;
                selectData.ZhuangDui = 0;
                selectData.XianDui = 0;
                selectData.CashType = false;
                selectData.CashChecked = false;
                selectData.ChipChecked = true;
            }

            StatisticsWagerInfo();
        }

        /// <summary>
        /// 设置筹码-点击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSetChips_Click(object sender, RoutedEventArgs e)
        {
            SetChips setChips = new SetChips();
            setChips.ShowDialog();
        }

        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            int[] result = new int[5];
            result[0] = GameBaseInfo.ZhuangIsChecked == true ? 1 : 0;
            result[1] = GameBaseInfo.XianIsChecked == true ? 1 : 0;
            result[2] = GameBaseInfo.HeIsChecked == true ? 1 : 0;
            result[3] = GameBaseInfo.ZhuangDuiIsChecked == true ? 1 : 0;
            result[4] = GameBaseInfo.XianDuiIsChecked == true ? 1 : 0;

            List<BaccatatWriteRecordBet> betData = new List<BaccatatWriteRecordBet>();

            var userWagerInfo = WagerInfo.GridData.Where(s => s.HasData == true).ToList();
            if (userWagerInfo != null && userWagerInfo.Count > 0)
            {
                foreach (var item in userWagerInfo)
                {
                    betData.Add(new BaccatatWriteRecordBet()
                    {
                        user_id = item.UserId,
                        username = item.UserName,
                        is_cash = item.CashType,
                        bet = new List<decimal>()
                        {
                            item.Zhuang,
                            item.Xian,
                            item.He,
                            item.ZhuangDui,
                            item.XianDui
                        }
                    });
                }
            }

            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.WriteRecord, JsonHelper.EntityToJson(new
            {
                game_id = Loginer.Id,
                write_type = 1,
                game_name = Loginer.GameName,
                chang = Loginer.Chang,
                ci = Loginer.Ci,
                type = GameType.Baccarat,
                result = result,
                data = betData

            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultWriteRecord>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                GameBaseInfo.Chang = resObjData.Data.Chang;
                GameBaseInfo.Ci = resObjData.Data.Ci;
                Loginer.Chang = resObjData.Data.Chang;
                Loginer.Ci = resObjData.Data.Ci;
                ReSetDewdropChecked();
                LoadDewdropInfo();

                SysHelper.ResetBaccaratWagerInfo(WagerInfo.GridData, GameBaseInfo);

                SysMessage.ShowNotification("操作成功！");
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }

        /// <summary>
        /// 重新选取
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            ReSetDewdropChecked();
        }

        /// <summary>
        /// 加载路单数据
        /// </summary>
        private void LoadDewdropInfo()
        {
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.GetRoadList, JsonHelper.EntityToJson(new
            {
                game_id = Loginer.Id,
                chang = Loginer.Chang,

            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                SysHelper.ConvertBaccaratDewdropInfo(resObjData.Data.road_list, DewdropInfo.GridData);
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }

        /// <summary>
        /// 重置路单选择
        /// </summary>
        private void ReSetDewdropChecked()
        {
            GameBaseInfo.ZhuangIsChecked = false;
            GameBaseInfo.ZhuangDuiIsChecked = false;
            GameBaseInfo.XianIsChecked = false;
            GameBaseInfo.XianDuiIsChecked = false;
            GameBaseInfo.HeIsChecked = false;
        }

        /// <summary>
        /// 注单单击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgWagerInfoDataGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var rowData = this.DgWagerInfoDataGrid.SelectedItem as BaccaratWagerInfoGrid;
            //BaccaratInput baccaratInput = new BaccaratInput();
            //baccaratInput.BaccaratWagerInfoGrid = this.WagerInfo.GridData.FirstOrDefault(s => s.Index == rowData.Index);
            //baccaratInput.CallBack = StatisticsWagerInfo;
            //baccaratInput.ShowDialog();

            //SysMessage.ShowMessage(JsonHelper.EntityToJson(rowData));
        }

        /// <summary>
        /// 账号文本框失去焦点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TbUserName_LostFocus(object sender, RoutedEventArgs e)
        {
            var rowData = this.DgWagerInfoDataGrid.SelectedItem as BaccaratWagerInfoGrid;
            rowData.UserId = 0;
            rowData.HasData = false;
            //rowData.UserName = string.Empty;

            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.DetailUser, JsonHelper.EntityToJson(new
            {
                username = (sender as TextBox).Text
            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                if (resObjData.Data.user_id <= 0)
                {
                    SysMessage.ShowNotification("未找到用户数据");
                    return;
                }

                rowData.UserId = resObjData.Data.user_id;
                rowData.UserName = (sender as TextBox).Text;
                rowData.HasData = true;
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }

        /// <summary>
        /// 统计注单信息
        /// </summary>
        private void StatisticsWagerInfo()
        {
            GameBaseInfo.AllZhaung = WagerInfo.GridData.Sum(e => e.Zhuang);
            GameBaseInfo.AllXian = WagerInfo.GridData.Sum(e => e.Xian);
            GameBaseInfo.AllHe = WagerInfo.GridData.Sum(e => e.He);
            GameBaseInfo.AllZhuangDui = WagerInfo.GridData.Sum(e => e.ZhuangDui);
            GameBaseInfo.AllXianDui = WagerInfo.GridData.Sum(e => e.XianDui);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnShiftChange_Click(object sender, RoutedEventArgs e)
        {
            ShiftChange shiftChange = new ShiftChange();
            shiftChange.ShowDialog();
        }

        /// <summary>
        /// 新靴
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnNewBoots_Click(object sender, RoutedEventArgs e)
        {
            if (SysMessage.ShowMessage("您确定要进行【新靴】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.NewShoe, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultWriteRecord>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    GameBaseInfo.Chang = resObjData.Data.Chang;
                    GameBaseInfo.Ci = resObjData.Data.Ci;
                    Loginer.Chang = resObjData.Data.Chang;
                    Loginer.Ci = resObjData.Data.Ci;
                    ReSetDewdropChecked();
                    LoadDewdropInfo();
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 台桌统计
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnStatistics_Click(object sender, RoutedEventArgs e)
        {
            SearchInfo searchInfo = new SearchInfo();
            searchInfo.ShowDialog();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            StatisticsWagerInfo();
        }
    }
}