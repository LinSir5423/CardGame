﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using CasualGames.Model.HttpResult;
using CasualGames.Model.ViewDatas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// ShiftChange.xaml 的交互逻辑
    /// </summary>
    public partial class ShiftChange : Window
    {
        /// <summary>
        /// 页面数据对象
        /// </summary>
        public ShiftChangeInfo ShiftChangeInfo;
        public ShiftChange()
        {
            InitializeComponent();
            ShiftChangeInfo = new ShiftChangeInfo();

            this.DataContext = ShiftChangeInfo;
        }

        #region 窗体事件
        /// <summary>
        /// 窗体关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 窗体移动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Source is StackPanel)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            //string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.DaySettlement, JsonHelper.EntityToJson(new
            //{
            //    game_id = Loginer.Id
            //}), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            //    {
            //        { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            //});

            //var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
            //if (string.IsNullOrEmpty(resObjData.Message))
            //{
            //    SysMessage.ShowNotification("操作成功！");
            //    this.Close();
            //}
            //else
            //{
            //    SysMessage.ShowNotification(resObjData.Message);
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            LoadData();
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        private void LoadData()
        {
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.CheckData, JsonHelper.EntityToJson(new
            {
                game_id = Loginer.Id
            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultCheckData>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                ShiftChangeInfo.coin_win_total = resObjData.Data.coin_win_total;
                ShiftChangeInfo.deduct_tie_total = resObjData.Data.deduct_tie_total;
                ShiftChangeInfo.deduct_pairs_total = resObjData.Data.deduct_pairs_total;
                ShiftChangeInfo.cash_win_total = resObjData.Data.cash_win_total;
                ShiftChangeInfo.cash_deduct_tie_total = resObjData.Data.cash_deduct_tie_total;
                ShiftChangeInfo.init_coin_amount = resObjData.Data.init_coin_amount;
                ShiftChangeInfo.init_cash_amount = resObjData.Data.init_cash_amount;
                ShiftChangeInfo.now_coin_amount = resObjData.Data.now_coin_amount;
                ShiftChangeInfo.now_cash_amount = resObjData.Data.now_cash_amount;
                ShiftChangeInfo.begin_time = resObjData.Data.begin_time;
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }
    }
}
