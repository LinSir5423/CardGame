﻿using CasualGames.Generic.Sys;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// 声明修改成功返回委托
    /// </summary>
    public delegate void EditCallBackDelegate();

    /// <summary>
    /// SetApiAddress.xaml 的交互逻辑
    /// </summary>
    public partial class SetApiAddress : Window
    {
        /// <summary>
        /// 回调委托
        /// </summary>
        public EditCallBackDelegate EditCallBack = null;

        public SetApiAddress()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            string strApi = this.TbGameId.Text.Trim();

            string cfgINI = AppDomain.CurrentDomain.BaseDirectory + Basis.INI_CFG;
            IniFile ini = new IniFile(cfgINI);
            ini.IniWriteValue("Api", "ApiAddress", strApi);
            Basis.CardGamesServerAddress = ini.IniReadValue("Api", "ApiAddress");

            EditCallBack?.Invoke();
            this.Close();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            string cfgINI = AppDomain.CurrentDomain.BaseDirectory + Basis.INI_CFG;
            if (File.Exists(cfgINI))
            {
                IniFile ini = new IniFile(cfgINI);
                Basis.CardGamesServerAddress = ini.IniReadValue("Api", "ApiAddress");
                this.TbGameId.Text = Basis.CardGamesServerAddress;
            }
        }
    }
}
