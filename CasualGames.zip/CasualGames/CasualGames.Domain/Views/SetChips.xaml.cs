﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using CasualGames.Model.HttpResult;
using CasualGames.Model.ViewDatas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// SetChips.xaml 的交互逻辑
    /// </summary>
    public partial class SetChips : Window
    {
        /// <summary>
        /// 页面基础数据
        /// </summary>
        public SetChipsBaseInfo SetChipsBaseInfo;

        public SetChips()
        {
            InitializeComponent();
            SetChipsBaseInfo = new SetChipsBaseInfo();

            this.DataContext = SetChipsBaseInfo;
        }

        #region 窗体事件
        /// <summary>
        /// 窗体关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 窗体移动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Source is StackPanel)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }
        #endregion

        /// <summary>
        /// 设置筹码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSetChips_Click(object sender, RoutedEventArgs e)
        {
            if (SysMessage.ShowMessage("您确定要进行【筹码设置】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.BeginInitAmount, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id,
                    coin_amount = SetChipsBaseInfo.SetChouMa,
                    cash_amount = SetChipsBaseInfo.SetXianJin
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            {
                { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    LoadData();
                    SysMessage.ShowNotification(resObjData.Data.msg);
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 加筹码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddChouMa_Click(object sender, RoutedEventArgs e)
        {
            if (SetChipsBaseInfo.AddChouMa <= 0)
            {
                SysMessage.ShowMessage("请输入筹码额度【正数】");
                return;
            }

            if (SysMessage.ShowMessage("您确定要进行【加筹码】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.SetAmount, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id,
                    type = 1,
                    amount = SetChipsBaseInfo.AddChouMa
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            {
                { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    LoadData();
                    SysMessage.ShowNotification(resObjData.Data.msg);
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 减筹码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSubtractChouMa_Click(object sender, RoutedEventArgs e)
        {
            if (SetChipsBaseInfo.SubtractChouMa <= 0)
            {
                SysMessage.ShowMessage("请输入筹码额度【正数】，后台有自动转为负数");
                return;
            }

            if (SysMessage.ShowMessage("您确定要进行【减筹码】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.SetAmount, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id,
                    type = 1,
                    amount = -SetChipsBaseInfo.SubtractChouMa
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            {
                { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    LoadData();
                    SysMessage.ShowNotification(resObjData.Data.msg);
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 加现金
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddXianJin_Click(object sender, RoutedEventArgs e)
        {
            if (SetChipsBaseInfo.AddXianJin <= 0)
            {
                SysMessage.ShowMessage("请输入金额【正数】");
                return;
            }

            if (SysMessage.ShowMessage("您确定要进行【加现金】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.SetAmount, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id,
                    type = 2,
                    amount = SetChipsBaseInfo.AddXianJin
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            {
                { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    LoadData();
                    SysMessage.ShowNotification(resObjData.Data.msg);
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 减现金
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSubtractXianJin_Click(object sender, RoutedEventArgs e)
        {
            if (SetChipsBaseInfo.SubtractXianJin <= 0)
            {
                SysMessage.ShowMessage("请输入金额【正数】，后台有自动转为负数");
                return;
            }

            if (SysMessage.ShowMessage("您确定要进行【减现金】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.SetAmount, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id,
                    type = 2,
                    amount = -SetChipsBaseInfo.SubtractXianJin
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
            {
                { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultBase>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    LoadData();
                    SysMessage.ShowNotification(resObjData.Data.msg);
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            LoadData();
        }

        /// <summary>
        /// 
        /// </summary>
        private void LoadData()
        {
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.CheckData, JsonHelper.EntityToJson(new
            {
                game_id = Loginer.Id
            }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

            var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultCheckData>>(resStringData);
            if (string.IsNullOrEmpty(resObjData.Message))
            {
                SetChipsBaseInfo.SetChouMa = resObjData.Data.init_coin_amount;
                SetChipsBaseInfo.SetXianJin = resObjData.Data.init_cash_amount;
                SetChipsBaseInfo.coin_win_total = resObjData.Data.coin_win_total;
                SetChipsBaseInfo.deduct_tie_total = resObjData.Data.deduct_tie_total;
                SetChipsBaseInfo.deduct_pairs_total = resObjData.Data.deduct_pairs_total;
                SetChipsBaseInfo.cash_win_total = resObjData.Data.cash_win_total;
                SetChipsBaseInfo.cash_deduct_tie_total = resObjData.Data.cash_deduct_tie_total;
                SetChipsBaseInfo.init_coin_amount = resObjData.Data.init_coin_amount;
                SetChipsBaseInfo.init_cash_amount = resObjData.Data.init_cash_amount;
                SetChipsBaseInfo.now_coin_amount = resObjData.Data.now_coin_amount;
                SetChipsBaseInfo.now_cash_amount = resObjData.Data.now_cash_amount;
                SetChipsBaseInfo.begin_time = resObjData.Data.begin_time;
            }
            else
            {
                SysMessage.ShowNotification(resObjData.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            if (SysMessage.ShowMessage("您确定要进行【台桌日结算】操作吗？", messageBoxButton: MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.DaySettlement, JsonHelper.EntityToJson(new
                {
                    game_id = Loginer.Id
                }), "application/json", strMethod: "Post", dicHeaders: new Dictionary<string, string>()
                {
                    { "Authorization",string.Format("{0}", Loginer.AccessToken)}
            });

                var resObjData = JsonHelper.JsonToObject<HttpResult<HttpResultCheckData>>(resStringData);
                if (string.IsNullOrEmpty(resObjData.Message))
                {
                    SysMessage.ShowNotification("结算操作成功！");
                    this.Close();
                }
                else
                {
                    SysMessage.ShowNotification(resObjData.Message);
                }
            }
        }
    }
}
