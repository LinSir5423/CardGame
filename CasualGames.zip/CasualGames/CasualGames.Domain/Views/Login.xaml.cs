﻿using CasualGames.Generic.Sys;
using CasualGames.Generic.Sys.AesHelper;
using CasualGames.Generic.Sys.Http;
using CasualGames.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CasualGames.Domain.Views
{
    /// <summary>
    /// Login.xaml 的交互逻辑
    /// </summary>
    public partial class Login : Window
    {
        /// <summary>
        /// 台号
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 是否记住密码
        /// </summary>
        public bool UserChecked { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Login()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ReadConfigInfo();
            this.TxtUserName.Text = Id;
            this.TxtPassword.Password = Password;
            this.CbRememberPassword.IsChecked = UserChecked;

            string cfgINI = AppDomain.CurrentDomain.BaseDirectory + Basis.INI_CFG;
            if (File.Exists(cfgINI))
            {
                IniFile ini = new IniFile(cfgINI);
                Basis.CardGamesServerAddress = ini.IniReadValue("Api", "ApiAddress");

                string strAuthorizationDate = ini.IniReadValue("Authorization", "AuthorizationDate");
                if (string.IsNullOrEmpty(strAuthorizationDate))
                {
                    ini.IniWriteValue("Authorization", "AuthorizationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                }
                else
                {
                    try
                    {
                        DateTime nowDate = DateTime.Now;
                        DateTime firstDateTime = DateTime.Parse(strAuthorizationDate);

                        if ((nowDate - firstDateTime).Days > 60)
                        {
                            ini.IniWriteValue("Authorization", "IsAuthorization", "N");
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(ini.IniReadValue("Authorization", "IsAuthorization")))
                            {
                                ini.IniWriteValue("Authorization", "IsAuthorization", "Y");
                            }
                        }
                    }
                    catch { }
                }
            }

            if (string.IsNullOrEmpty(Basis.CardGamesServerAddress))
            {
                this.BtnSetting.Content = "设置接口地址【未设置】";
            }
            else
            {
                this.BtnSetting.Content = "设置接口地址【已设置】";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                base.DragMove();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnClose_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(Basis.CardGamesServerAddress))
            {
                SysMessage.Info("您还未设置接口地址，请先设置");
                return;
            }

            try
            {
                this.Id = this.TxtUserName.Text.Trim();
                int id = int.Parse(this.TxtUserName.Text.Trim());
            }
            catch
            {
                SysMessage.ShowMessage("【台号】不能为空，且只能为正整数");
                return;
            }

            this.Password = this.TxtPassword.Password.Trim();
            this.UserChecked = (bool)this.CbRememberPassword.IsChecked;

            if (string.IsNullOrEmpty(Password))
            {
                SysMessage.ShowMessage("【密码】不能为空");
                return;
            }

            var hander = SysMessage.Loading();
            string resStringData = HttpHelper.RequestHttp(Basis.CardGamesServerAddress.TrimEnd('/') + HttpHelper.Login,
                JsonHelper.EntityToJson(new { id = int.Parse(Id), pass = Password }), "application/json");
            hander.Close();

            var resObjData = JsonHelper.JsonToObject<HttpResult<LoginInfo>>(resStringData);

            if (resObjData.Data != null)
            {
                SaveLoginInfo(UserChecked ? true : false);
                Loginer.LoginTime = DateTime.Now;
                Loginer.LoginTime = DateTime.Now;
                Loginer.Password = Password;

                Loginer.AccessToken = resObjData.Data.token;
                Loginer.Id = resObjData.Data.id;
                Loginer.GameName = resObjData.Data.game_name;
                Loginer.GameType = resObjData.Data.game_type;
                Loginer.LimitRed = resObjData.Data.limit_red;
                Loginer.Chang = resObjData.Data.chang;
                Loginer.Ci = resObjData.Data.ci;
                Loginer.RoadList = resObjData.Data.road_list;

                if (Loginer.GameType == Model.Enums.GameType.Baccarat)
                {
                    BaccaratMain baccaratMain = new BaccaratMain();
                    baccaratMain.Show();
                    baccaratMain.GameBaseInfo.TaiNumber = Loginer.Id;
                    baccaratMain.GameBaseInfo.Chang = Loginer.Chang;
                    baccaratMain.GameBaseInfo.Ci = Loginer.Ci;
                    baccaratMain.GameBaseInfo.Red = Loginer.LimitRed;
                    this.Close();
                }
                else if (Loginer.GameType == Model.Enums.GameType.Pred)
                {
                    PredMain predMain = new PredMain();
                    predMain.Show();
                    predMain.GameBaseInfo.TaiNumber = Loginer.Id;
                    predMain.GameBaseInfo.Chang = Loginer.Chang;
                    predMain.GameBaseInfo.Ci = Loginer.Ci;
                    predMain.GameBaseInfo.Red = Loginer.LimitRed;
                    this.Close();
                }
                else if (Loginer.GameType == Model.Enums.GameType.Taurus || Loginer.GameType == Model.Enums.GameType.ShuangLian || Loginer.GameType == Model.Enums.GameType.SanGong)
                {
                    TaurusMain taurusMain = new TaurusMain();
                    taurusMain.Show();
                    taurusMain.GameBaseInfo.TaiNumber = Loginer.Id;
                    taurusMain.GameBaseInfo.Chang = Loginer.Chang;
                    taurusMain.GameBaseInfo.Ci = Loginer.Ci;
                    taurusMain.GameBaseInfo.Red = Loginer.LimitRed;
                    this.Close();
                }
                else if (Loginer.GameType == Model.Enums.GameType.TongZi)
                {
                    TongZiMain tongZiMain = new TongZiMain();
                    tongZiMain.Show();
                    tongZiMain.GameBaseInfo.TaiNumber = Loginer.Id;
                    tongZiMain.GameBaseInfo.Chang = Loginer.Chang;
                    tongZiMain.GameBaseInfo.Ci = Loginer.Ci;
                    tongZiMain.GameBaseInfo.Red = Loginer.LimitRed;
                    this.Close();
                }
                else
                {
                    SysMessage.ShowMessage("游戏类型错误，登录失败");
                }
            }
            else
            {
                string message = resObjData.Message == null ? "登录失败，账号或密码错误" : resObjData.Message;
                SysMessage.Error(message);
            }
        }


        /// <summary>
        /// 保存登录信息
        /// </summary>
        /// <param name="haveInfo"></param>
        private void SaveLoginInfo(bool haveInfo = true)
        {
            string cfgINI = AppDomain.CurrentDomain.BaseDirectory + Basis.INI_CFG;
            IniFile ini = new IniFile(cfgINI);
            ini.IniWriteValue("Login", "User", haveInfo ? Id.ToString() : "");
            ini.IniWriteValue("Login", "Password", AesHelper.Encrypt(haveInfo ? Password : "", Basis.AesSecretKey));
            ini.IniWriteValue("Login", "SaveInfo", haveInfo ? (UserChecked ? "Y" : "N") : "N");
        }

        /// <summary>
        /// 读取本地配置信息
        /// </summary>
        private void ReadConfigInfo()
        {
            string cfgINI = AppDomain.CurrentDomain.BaseDirectory + Basis.INI_CFG;
            if (File.Exists(cfgINI))
            {
                IniFile ini = new IniFile(cfgINI);
                Id = ini.IniReadValue("Login", "User");
                Password = string.IsNullOrEmpty(ini.IniReadValue("Login", "Password")) ? null : AesHelper.Decrypt(ini.IniReadValue("Login", "Password"), Basis.AesSecretKey);
                UserChecked = ini.IniReadValue("Login", "SaveInfo") == "Y";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSetting_Click(object sender, RoutedEventArgs e)
        {
            SetApiAddress setWindow = new SetApiAddress();
            setWindow.EditCallBack = CallBack;
            setWindow.ShowDialog();

        }

        /// <summary>
        /// 
        /// </summary>
        private void CallBack()
        {
            if (string.IsNullOrEmpty(Basis.CardGamesServerAddress))
            {
                this.BtnSetting.Content = "设置接口地址【未设置】";
            }
            else
            {
                this.BtnSetting.Content = "设置接口地址【已设置】";
            }
        }
    }
}
