﻿using Panuon.UI.Silver;
using Panuon.UI.Silver.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace CasualGames.Domain
{
    public class SysMessage
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="title"></param>
        /// <param name="owner"></param>
        /// <param name="messageBoxButton"></param>
        /// <param name="configurations"></param>
        /// <returns></returns>
        public static MessageBoxResult ShowMessage(string msg, string title = "信息提示", Window owner = null, MessageBoxButton messageBoxButton = MessageBoxButton.OK, MessageBoxXConfigurations configurations = null)
        {
            if (owner == null)
            {
                owner = Application.Current.MainWindow;
            }

            if (configurations == null)
            {
                configurations = new MessageBoxXConfigurations()
                {
                    OKButton = "确定",
                    CancelButton = "取消",
                    MessageBoxIcon = MessageBoxIcon.Info,
                    ButtonBrush = "#1E9FFF".ToColor().ToBrush(),
                };
            }

            var result = MessageBoxX.Show(msg, title, owner, messageBoxButton, configurations);

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static MessageBoxResult Error(string msg)
        {
            return ShowMessage(msg, "错误提示", configurations: new MessageBoxXConfigurations()
            {
                OKButton = "确定",
                MessageBoxIcon = MessageBoxIcon.Error,
                ButtonBrush = "#FF4C4C".ToColor().ToBrush(),
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static MessageBoxResult Info(string msg)
        {
            return ShowMessage(msg, "信息提示", configurations: new MessageBoxXConfigurations()
            {
                OKButton = "确定",
                MessageBoxIcon = MessageBoxIcon.Info,
                ButtonBrush = "#1E9FFF".ToColor().ToBrush(),
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="title"></param>
        /// <param name="cancelable"></param>
        /// <param name="owner"></param>
        /// <param name="configurations"></param>
        /// <returns></returns>
        public static IPendingHandler ShowLoading(string message, string title = null, bool cancelable = false, Window owner = null, PendingBoxConfigurations configurations = null)
        {
            if (owner == null)
            {
                owner = Application.Current.MainWindow;
            }

            if (configurations == null)
            {
                configurations = new PendingBoxConfigurations()
                {
                    Topmost = true,
                    LoadingForeground = Colors.Red.ToBrush(),
                    ButtonBrush = "#5DBBEC".ToColor().ToBrush(),
                };
            }

            var handler = PendingBox.Show(message, title, cancelable, owner, configurations);
            handler.Cancel += delegate
            {
                handler.Close();
            };

            return handler;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="title"></param>
        /// <returns></returns>
        public static IPendingHandler Loading(string msg = "加载中，请等待...", string title = null)
        {
            return ShowLoading(msg, title);
        }

        /// <summary>
        /// 有下角显示通知消息
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="title"></param>
        public static void ShowNotification(string msg, string title = null)
        {
            Message.NotifyData data = new Message.NotifyData();
            data.Title = title == null ? "通知消息" : title;
            data.Content = msg;

            Message.NotificationWindow dialog = new Message.NotificationWindow();
            dialog.DataContext = data;
            dialog.Show();
        }
    }
}
