﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Interop;

namespace CasualGames.Domain
{
    /// <summary>
    /// Wpf应用程序全屏辅助类
    /// </summary>
    public static class FullScreenHelper
    {
        /// <summary>
        /// 是否是全屏
        /// </summary>
        public static bool IsFullScreen = true;

        /// <summary>
        /// 进入全屏
        /// </summary>
        /// <param name="window"></param>
        public static void GoFullscreen(this Window window)
        {
            //变成无边窗体
            window.WindowState = WindowState.Normal;
            window.WindowStyle = WindowStyle.None;
            window.ResizeMode = ResizeMode.NoResize;

            //获取窗口句柄 
            var handle = new WindowInteropHelper(window).Handle;

            //获取当前显示器屏幕
            Screen screen = Screen.FromHandle(handle);

            //调整窗口最大化,全屏的关键代码就是下面3句
            window.MaxWidth = screen.Bounds.Width;
            window.MaxHeight = screen.Bounds.Height;
            window.WindowState = WindowState.Maximized;
            IsFullScreen = true;
        }

        /// <summary>
        /// 退出全屏
        /// </summary>
        /// <param name="window"></param>
        public static void ExitFullscreen(this Window window)
        {
            //变成无边窗体
            window.WindowState = WindowState.Normal;
            window.WindowStyle = WindowStyle.None;
            window.ResizeMode = ResizeMode.NoResize;

            //获取窗口句柄 
            var handle = new WindowInteropHelper(window).Handle;

            //获取当前显示器屏幕
            Screen screen = Screen.FromHandle(handle);

            //调整窗口最大化,全屏的关键代码就是下面3句
            window.MaxWidth = screen.WorkingArea.Width;
            window.MaxHeight = screen.WorkingArea.Height;
            window.WindowState = WindowState.Maximized;
            IsFullScreen = false;
        }
    }
}
