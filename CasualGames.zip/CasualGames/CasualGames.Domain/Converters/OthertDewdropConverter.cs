﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace CasualGames.Domain.Converters
{
    /// <summary>
    /// 其他游戏露珠转换【牛牛、筒子、双联、三公】
    /// </summary>
    public class OthertDewdropConverter : IValueConverter
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string temValue = ((string)value);
            if (string.IsNullOrEmpty(temValue))
            {
                return null;
            }

            return SysHelper.GetImageBrush(string.Format("/Resources/Images/Otrer-Dewdrop-{0}.png", temValue.ToUpper()));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
