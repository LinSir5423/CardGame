﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace CasualGames.Domain.Converters
{
    /// <summary>
    /// 整数零转换器
    /// </summary>
    public class ZeroConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            decimal tempVale = 0;
            decimal.TryParse(value.ToString(), out tempVale);

            return tempVale <= 0 ? "" : value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
            //decimal tempVale = 0;
            //decimal.TryParse(value.ToString(), out tempVale);

            //return tempVale <= 0 ? 0.00M : Math.Round(tempVale, 2);
        }
    }
}
