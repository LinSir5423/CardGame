﻿using CasualGames.Model.ViewDatas;
using CasualGames.Model.ViewDatas.Pred;
using CasualGames.Model.ViewDatas.Pred.Dewdrop;
using CasualGames.Model.ViewDatas.Taurus;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CasualGames.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public static class SysHelper
    {

        /// <summary>
        /// 根据图片的相对路径 返回 BitmapImage对象的实例化
        /// </summary>
        /// <param name="imgPath">图片的相对路径(如:@"/images/star.png")</param>
        /// <returns></returns>
        public static BitmapImage GetBitmapImage(string imgPath)
        {
            try
            {
                if (!imgPath.StartsWith("/"))
                {
                    imgPath = "/" + imgPath;
                }
                return new BitmapImage(new Uri("pack://application:,,,/CasualGames.Domain;component" + imgPath));
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// 根据图片的相对路径 获取ImageBrush对象 (此对象资源可以直接用于绑定控件的Background属性)
        /// </summary>
        /// <param name="imgPath">图片的相对路径(如:@"/images/star.png")</param>
        /// <returns></returns>
        public static ImageBrush GetImageBrush(string imgPath)
        {
            ImageBrush ib = new ImageBrush();
            ib.ImageSource = GetBitmapImage(imgPath);
            ib.Stretch = Stretch.Uniform;
            return ib;
        }

        /// <summary>
        /// 初始化百家乐注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void InitBaccaratWagerInfo(ObservableCollection<BaccaratWagerInfoGrid> gridData)
        {
            gridData.Clear();
            for (int i = 1; i <= 8; i++)
            {
                gridData.Add(new BaccaratWagerInfoGrid()
                {
                    HasData = false,
                    Index = i,
                    UserName = string.Empty,
                    UserId = 0,
                    Zhuang = 0,
                    Xian = 0,
                    He = 0,
                    ZhuangDui = 0,
                    XianDui = 0,
                    CashType = false,
                    ChipChecked = true,
                    CashChecked = false
                });
            }
        }

        /// <summary>
        /// 重置百家乐注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void ResetBaccaratWagerInfo(ObservableCollection<BaccaratWagerInfoGrid> gridData, GameBaseInfo gameBaseInfo)
        {
            foreach (var item in gridData)
            {
                //item.HasData = false;
                item.Zhuang = 0;
                item.Xian = 0;
                item.He = 0;
                item.ZhuangDui = 0;
                item.XianDui = 0;
                item.CashType = false;
                item.ZhuangText = string.Empty;
                item.XianText = string.Empty;
                item.HeText = string.Empty;
                item.ZhuangDuiText = string.Empty;
                item.XianDuiText = string.Empty;
            }

            gameBaseInfo.AllZhaung = gridData.Sum(e => e.Zhuang);
            gameBaseInfo.AllXian = gridData.Sum(e => e.Xian);
            gameBaseInfo.AllHe = gridData.Sum(e => e.He);
            gameBaseInfo.AllZhuangDui = gridData.Sum(e => e.ZhuangDui);
            gameBaseInfo.AllXianDui = gridData.Sum(e => e.XianDui);
        }

        /// <summary>
        /// 初始化龙虎注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void InitPredWagerInfo(ObservableCollection<PredWagerInfoGrid> gridData)
        {
            gridData.Clear();
            for (int i = 1; i <= 8; i++)
            {
                gridData.Add(new PredWagerInfoGrid()
                {
                    HasData = false,
                    Index = i,
                    UserName = string.Empty,
                    UserId = 0,
                    Long = 0,
                    Hu = 0,
                    He = 0,
                    CashType = false,
                    ChipChecked = true,
                    CashChecked = false
                });
            }
        }

        /// <summary>
        /// 重置龙虎注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void ResetPredWagerInfo(ObservableCollection<PredWagerInfoGrid> gridData, PredBaseInfo gameBaseInfo)
        {
            foreach (var item in gridData)
            {
                //item.HasData = false;
                item.Long = 0;
                item.Hu = 0;
                item.He = 0;
                item.CashType = false;
                item.LongText = string.Empty;
                item.HuText = string.Empty;
                item.HeText = string.Empty;
            }

            gameBaseInfo.AllLong = gridData.Sum(e => e.Long);
            gameBaseInfo.AllHu = gridData.Sum(e => e.Hu);
            gameBaseInfo.AllHe = gridData.Sum(e => e.He);
        }

        /// <summary>
        /// 初始化牛牛注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void InitTaurusWagerInfo(ObservableCollection<TaurusWagerInfoGrid> gridData)
        {
            gridData.Clear();
            for (int i = 1; i <= 8; i++)
            {
                gridData.Add(new TaurusWagerInfoGrid()
                {
                    HasData = false,
                    Index = i,
                    UserName = string.Empty,
                    UserId = 0,
                    XianYi = 0,
                    XianEr = 0,
                    XianSan = 0,
                    XianSi = 0,
                    XianWu = 0,
                    XianLiu = 0,
                    CashType = false,
                    ChipChecked = true,
                    CashChecked = false
                });
            }
        }

        /// <summary>
        /// 重置化牛牛注单信息
        /// </summary>
        /// <param name="gridData"></param>
        public static void ResetTaurusWagerInfo(ObservableCollection<TaurusWagerInfoGrid> gridData, TaurusBaseInfo gameBaseInfo)
        {
            foreach (var item in gridData)
            {
                //item.HasData = false;
                item.XianYi = 0;
                item.XianEr = 0;
                item.XianSan = 0;
                item.XianSi = 0;
                item.XianWu = 0;
                item.XianLiu = 0;
                item.CashType = false;
                item.XianYiText = string.Empty;
                item.XianErText = string.Empty;
                item.XianSanText = string.Empty;
                item.XianSiText = string.Empty;
                item.XianWuText = string.Empty;
                item.XianLiuText = string.Empty;
            }

            gameBaseInfo.AllXianYi = gridData.Sum(e => e.XianYi);
            gameBaseInfo.AllXianEr = gridData.Sum(e => e.XianEr);
            gameBaseInfo.AllXianSan = gridData.Sum(e => e.XianSan);
            gameBaseInfo.AllXianSi = gridData.Sum(e => e.XianSi);
            gameBaseInfo.AllXianWu = gridData.Sum(e => e.XianWu);
            gameBaseInfo.AllXianLiu = gridData.Sum(e => e.XianLiu);
        }

        /// <summary>
        /// 转换百家乐露珠数据【龙虎通用】
        /// string strDewdrop = "c,a,a,a,c,c,e,a,i,c,c,e,b,e,c,c,a,a,e,a,c,c,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,a,e,c,a,a,e,a,e,e,e,e,a,e,a,i,a,e,e,b,e,a,a,a,a,e,a,e,e,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,e,e,e,a,e,i,e,e,c";
        /// </summary>
        /// <param name="strDewdrop">获取到的露珠数据串</param>
        /// <param name="gridData">绑定的数据对象</param>
        public static void ConvertBaccaratDewdropInfo(string strDewdrop, ObservableCollection<BaccaratDewdropInfoGrid> gridData)
        {
            gridData.Clear();
            string[] arrDewdrop = new string[132];
            string[] sourceDewdrop = strDewdrop.Split(',');

            int sourceIndex = sourceDewdrop.Length <= 131 ? 0 : ((sourceDewdrop.Length % 132) / 6) * 6 + 6;
            int moveLength = sourceDewdrop.Length - sourceIndex;
            Array.Copy(sourceDewdrop, sourceIndex, arrDewdrop, 0, moveLength);


            for (int i = 0; i < 6; i++)
            {
                gridData.Add(new BaccaratDewdropInfoGrid()
                {
                    GridData01 = arrDewdrop.Length >= (i + 0 + 1) ? arrDewdrop[(i + 0)] : null,
                    GridData02 = arrDewdrop.Length >= (i + 6 + 1) ? arrDewdrop[(i + 6)] : null,
                    GridData03 = arrDewdrop.Length >= (i + 12 + 1) ? arrDewdrop[(i + 12)] : null,
                    GridData04 = arrDewdrop.Length >= (i + 18 + 1) ? arrDewdrop[(i + 18)] : null,
                    GridData05 = arrDewdrop.Length >= (i + 24 + 1) ? arrDewdrop[(i + 24)] : null,
                    GridData06 = arrDewdrop.Length >= (i + 30 + 1) ? arrDewdrop[(i + 30)] : null,
                    GridData07 = arrDewdrop.Length >= (i + 36 + 1) ? arrDewdrop[(i + 36)] : null,
                    GridData08 = arrDewdrop.Length >= (i + 42 + 1) ? arrDewdrop[(i + 42)] : null,
                    GridData09 = arrDewdrop.Length >= (i + 48 + 1) ? arrDewdrop[(i + 48)] : null,
                    GridData10 = arrDewdrop.Length >= (i + 54 + 1) ? arrDewdrop[(i + 54)] : null,

                    GridData11 = arrDewdrop.Length >= (i + 60 + 1) ? arrDewdrop[(i + 60)] : null,
                    GridData12 = arrDewdrop.Length >= (i + 66 + 1) ? arrDewdrop[(i + 66)] : null,
                    GridData13 = arrDewdrop.Length >= (i + 72 + 1) ? arrDewdrop[(i + 72)] : null,
                    GridData14 = arrDewdrop.Length >= (i + 78 + 1) ? arrDewdrop[(i + 78)] : null,
                    GridData15 = arrDewdrop.Length >= (i + 84 + 1) ? arrDewdrop[(i + 84)] : null,
                    GridData16 = arrDewdrop.Length >= (i + 90 + 1) ? arrDewdrop[(i + 90)] : null,
                    GridData17 = arrDewdrop.Length >= (i + 96 + 1) ? arrDewdrop[(i + 96)] : null,
                    GridData18 = arrDewdrop.Length >= (i + 102 + 1) ? arrDewdrop[(i + 102)] : null,
                    GridData19 = arrDewdrop.Length >= (i + 108 + 1) ? arrDewdrop[(i + 108)] : null,
                    GridData20 = arrDewdrop.Length >= (i + 114 + 1) ? arrDewdrop[(i + 114)] : null,

                    GridData21 = arrDewdrop.Length >= (i + 120 + 1) ? arrDewdrop[(i + 120)] : null,
                    GridData22 = arrDewdrop.Length >= (i + 126 + 1) ? arrDewdrop[(i + 126)] : null
                });
            }
        }

        /// <summary>
        /// 转换百家乐露珠数据【龙虎通用】
        /// string strDewdrop = "c,a,a,a,c,c,e,a,i,c,c,e,b,e,c,c,a,a,e,a,c,c,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,a,e,c,a,a,e,a,e,e,e,e,a,e,a,i,a,e,e,b,e,a,a,a,a,e,a,e,e,e,a,i,e,e,e,e,i,e,e,a,a,i,a,e,i,e,e,e,a,e,i,e,e,c";
        /// </summary>
        /// <param name="strDewdrop">获取到的露珠数据串</param>
        /// <param name="gridData">绑定的数据对象</param>
        public static void ConvertPredDewdropInfo(string strDewdrop, ObservableCollection<PredDewdropInfoGrid> gridData)
        {
            gridData.Clear();
            string[] arrDewdrop = new string[132];
            string[] sourceDewdrop = strDewdrop.Split(',');

            int sourceIndex = sourceDewdrop.Length <= 131 ? 0 : ((sourceDewdrop.Length % 132) / 6) * 6 + 6;
            int moveLength = sourceDewdrop.Length - sourceIndex;
            Array.Copy(sourceDewdrop, sourceIndex, arrDewdrop, 0, moveLength);


            for (int i = 0; i < 6; i++)
            {
                gridData.Add(new PredDewdropInfoGrid()
                {
                    GridData01 = arrDewdrop.Length >= (i + 0 + 1) ? arrDewdrop[(i + 0)] : null,
                    GridData02 = arrDewdrop.Length >= (i + 6 + 1) ? arrDewdrop[(i + 6)] : null,
                    GridData03 = arrDewdrop.Length >= (i + 12 + 1) ? arrDewdrop[(i + 12)] : null,
                    GridData04 = arrDewdrop.Length >= (i + 18 + 1) ? arrDewdrop[(i + 18)] : null,
                    GridData05 = arrDewdrop.Length >= (i + 24 + 1) ? arrDewdrop[(i + 24)] : null,
                    GridData06 = arrDewdrop.Length >= (i + 30 + 1) ? arrDewdrop[(i + 30)] : null,
                    GridData07 = arrDewdrop.Length >= (i + 36 + 1) ? arrDewdrop[(i + 36)] : null,
                    GridData08 = arrDewdrop.Length >= (i + 42 + 1) ? arrDewdrop[(i + 42)] : null,
                    GridData09 = arrDewdrop.Length >= (i + 48 + 1) ? arrDewdrop[(i + 48)] : null,
                    GridData10 = arrDewdrop.Length >= (i + 54 + 1) ? arrDewdrop[(i + 54)] : null,

                    GridData11 = arrDewdrop.Length >= (i + 60 + 1) ? arrDewdrop[(i + 60)] : null,
                    GridData12 = arrDewdrop.Length >= (i + 66 + 1) ? arrDewdrop[(i + 66)] : null,
                    GridData13 = arrDewdrop.Length >= (i + 72 + 1) ? arrDewdrop[(i + 72)] : null,
                    GridData14 = arrDewdrop.Length >= (i + 78 + 1) ? arrDewdrop[(i + 78)] : null,
                    GridData15 = arrDewdrop.Length >= (i + 84 + 1) ? arrDewdrop[(i + 84)] : null,
                    GridData16 = arrDewdrop.Length >= (i + 90 + 1) ? arrDewdrop[(i + 90)] : null,
                    GridData17 = arrDewdrop.Length >= (i + 96 + 1) ? arrDewdrop[(i + 96)] : null,
                    GridData18 = arrDewdrop.Length >= (i + 102 + 1) ? arrDewdrop[(i + 102)] : null,
                    GridData19 = arrDewdrop.Length >= (i + 108 + 1) ? arrDewdrop[(i + 108)] : null,
                    GridData20 = arrDewdrop.Length >= (i + 114 + 1) ? arrDewdrop[(i + 114)] : null,

                    GridData21 = arrDewdrop.Length >= (i + 120 + 1) ? arrDewdrop[(i + 120)] : null,
                    GridData22 = arrDewdrop.Length >= (i + 126 + 1) ? arrDewdrop[(i + 126)] : null
                });
            }
        }

        /// <summary>
        /// 转换牛牛露珠数据
        /// string strDewdrop = "[1,1,1,1,1,0],[0,1,0,0,1,0],[0,1,1,1,1,0],[1,0,0,1,1,0],[1,1,1,1,1,1],[0,1,0,1,0,0]"
        /// </summary>
        /// <param name="strDewdrop">获取到的露珠数据串</param>
        /// <param name="gridData">绑定的数据对象</param>
        public static void ConvertTaurusDewdropInfo(string strDewdrop, ObservableCollection<TaurusDewdropInfoGrid> gridData)
        {
            strDewdrop = strDewdrop.Replace("[", string.Empty).Replace("]", string.Empty);

            gridData.Clear();
            string[] arrDewdrop = new string[132];
            string[] sourceDewdrop = strDewdrop.Split(',');

            int sourceIndex = sourceDewdrop.Length <= 131 ? 0 : ((sourceDewdrop.Length % 132) / 6) * 6 + 6;
            int moveLength = sourceDewdrop.Length - sourceIndex;
            Array.Copy(sourceDewdrop, sourceIndex, arrDewdrop, 0, moveLength);


            for (int i = 0; i < 6; i++)
            {
                gridData.Add(new TaurusDewdropInfoGrid()
                {
                    GridData01 = arrDewdrop.Length >= (i + 0 + 1) ? arrDewdrop[(i + 0)] : null,
                    GridData02 = arrDewdrop.Length >= (i + 6 + 1) ? arrDewdrop[(i + 6)] : null,
                    GridData03 = arrDewdrop.Length >= (i + 12 + 1) ? arrDewdrop[(i + 12)] : null,
                    GridData04 = arrDewdrop.Length >= (i + 18 + 1) ? arrDewdrop[(i + 18)] : null,
                    GridData05 = arrDewdrop.Length >= (i + 24 + 1) ? arrDewdrop[(i + 24)] : null,
                    GridData06 = arrDewdrop.Length >= (i + 30 + 1) ? arrDewdrop[(i + 30)] : null,
                    GridData07 = arrDewdrop.Length >= (i + 36 + 1) ? arrDewdrop[(i + 36)] : null,
                    GridData08 = arrDewdrop.Length >= (i + 42 + 1) ? arrDewdrop[(i + 42)] : null,
                    GridData09 = arrDewdrop.Length >= (i + 48 + 1) ? arrDewdrop[(i + 48)] : null,
                    GridData10 = arrDewdrop.Length >= (i + 54 + 1) ? arrDewdrop[(i + 54)] : null,

                    GridData11 = arrDewdrop.Length >= (i + 60 + 1) ? arrDewdrop[(i + 60)] : null,
                    GridData12 = arrDewdrop.Length >= (i + 66 + 1) ? arrDewdrop[(i + 66)] : null,
                    GridData13 = arrDewdrop.Length >= (i + 72 + 1) ? arrDewdrop[(i + 72)] : null,
                    GridData14 = arrDewdrop.Length >= (i + 78 + 1) ? arrDewdrop[(i + 78)] : null,
                    GridData15 = arrDewdrop.Length >= (i + 84 + 1) ? arrDewdrop[(i + 84)] : null,
                    GridData16 = arrDewdrop.Length >= (i + 90 + 1) ? arrDewdrop[(i + 90)] : null,
                    GridData17 = arrDewdrop.Length >= (i + 96 + 1) ? arrDewdrop[(i + 96)] : null,
                    GridData18 = arrDewdrop.Length >= (i + 102 + 1) ? arrDewdrop[(i + 102)] : null,
                    GridData19 = arrDewdrop.Length >= (i + 108 + 1) ? arrDewdrop[(i + 108)] : null,
                    GridData20 = arrDewdrop.Length >= (i + 114 + 1) ? arrDewdrop[(i + 114)] : null,

                    GridData21 = arrDewdrop.Length >= (i + 120 + 1) ? arrDewdrop[(i + 120)] : null,
                    GridData22 = arrDewdrop.Length >= (i + 126 + 1) ? arrDewdrop[(i + 126)] : null
                });
            }
        }


        /// <summary>
        /// 转换筒子露珠数据
        /// string strDewdrop = "[1,1,1,1,1],[0,1,0,0,0],[0,1,1,1,0],[1,0,1,1,0],[1,1,1,1,1],[0,1,0,0,0]"
        /// </summary>
        /// <param name="strDewdrop">获取到的露珠数据串</param>
        /// <param name="gridData">绑定的数据对象</param>
        public static void ConvertTongZiDewdropInfo(string strDewdrop, ObservableCollection<TaurusDewdropInfoGrid> gridData)
        {
            strDewdrop = strDewdrop.Replace("[", string.Empty).Replace("]", string.Empty);

            gridData.Clear();
            string[] arrDewdrop = new string[90];
            string[] sourceDewdrop = strDewdrop.Split(',');

            int sourceIndex = sourceDewdrop.Length <= 98 ? 0 : ((sourceDewdrop.Length % 90) / 5) * 5 + 5;
            int moveLength = sourceDewdrop.Length - sourceIndex;
            Array.Copy(sourceDewdrop, sourceIndex, arrDewdrop, 0, moveLength);


            for (int i = 0; i < 6; i++)
            {
                gridData.Add(new TaurusDewdropInfoGrid()
                {
                    GridData01 = arrDewdrop.Length >= (i + 0 + 1) ? arrDewdrop[(i + 0)] : null,
                    GridData02 = arrDewdrop.Length >= (i + 5 + 1) ? arrDewdrop[(i + 5)] : null,
                    GridData03 = arrDewdrop.Length >= (i + 10 + 1) ? arrDewdrop[(i + 10)] : null,
                    GridData04 = arrDewdrop.Length >= (i + 15 + 1) ? arrDewdrop[(i + 15)] : null,
                    GridData05 = arrDewdrop.Length >= (i + 20 + 1) ? arrDewdrop[(i + 20)] : null,
                    GridData06 = arrDewdrop.Length >= (i + 25 + 1) ? arrDewdrop[(i + 25)] : null,
                    GridData07 = arrDewdrop.Length >= (i + 30 + 1) ? arrDewdrop[(i + 30)] : null,
                    GridData08 = arrDewdrop.Length >= (i + 35 + 1) ? arrDewdrop[(i + 35)] : null,
                    GridData09 = arrDewdrop.Length >= (i + 40 + 1) ? arrDewdrop[(i + 40)] : null,
                    GridData10 = arrDewdrop.Length >= (i + 45 + 1) ? arrDewdrop[(i + 45)] : null,

                    GridData11 = arrDewdrop.Length >= (i + 50 + 1) ? arrDewdrop[(i + 50)] : null,
                    GridData12 = arrDewdrop.Length >= (i + 55 + 1) ? arrDewdrop[(i + 55)] : null,
                    GridData13 = arrDewdrop.Length >= (i + 60 + 1) ? arrDewdrop[(i + 60)] : null,
                    GridData14 = arrDewdrop.Length >= (i + 65 + 1) ? arrDewdrop[(i + 65)] : null,
                    GridData15 = arrDewdrop.Length >= (i + 70 + 1) ? arrDewdrop[(i + 70)] : null,
                    GridData16 = arrDewdrop.Length >= (i + 75 + 1) ? arrDewdrop[(i + 75)] : null,
                    GridData17 = arrDewdrop.Length >= (i + 80 + 1) ? arrDewdrop[(i + 80)] : null,
                    GridData18 = arrDewdrop.Length >= (i + 85 + 1) ? arrDewdrop[(i + 85)] : null,
                });
            }
        }
    }
}
