﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.HttpResult
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpResultBase
    {
        /// <summary>
        /// 
        /// </summary>
        public string msg { get; set; }

        /// <summary>
        /// 游戏路单
        /// </summary>
        public string road_list { get; set; }

        /// <summary>
        /// 用户账号
        /// </summary>
        public int user_id { get; set; }

        /// <summary>
        /// 用户姓名
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// 用户昵称
        /// </summary>
        public string nickname { get; set; }

    }
}