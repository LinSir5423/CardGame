﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.HttpResult
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpResultWriteRecord : HttpResultBase
    {
        /// <summary>
        /// 
        /// </summary>
        public int Chang { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Ci { get; set; }
    }
}
