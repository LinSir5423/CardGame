﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.HttpResult
{
    /// <summary>
    /// 交接班数据核对
    /// </summary>
    public class HttpResultCheckData : HttpResultBase
    {
        /// <summary>
        /// 筹码总赢
        /// </summary>
        public decimal coin_win_total { get; set; }

        /// <summary>
        /// 筹码和扣底
        /// </summary>
        public decimal deduct_tie_total { get; set; }

        /// <summary>
        /// 筹码对子扣底
        /// </summary>
        public decimal deduct_pairs_total { get; set; }

        /// <summary>
        /// 	现金总赢
        /// </summary>
        public decimal cash_win_total { get; set; }

        /// <summary>
        /// 现金和扣底
        /// </summary>
        public decimal cash_deduct_tie_total { get; set; }

        /// <summary>
        /// 现金筹码扣底
        /// </summary>
        public decimal cash_deduct_pairs_total { get; set; }

        /// <summary>
        /// 初始化筹码金额
        /// </summary>
        public decimal init_coin_amount { get; set; }

        /// <summary>
        /// 初始化现金金额
        /// </summary>
        public decimal init_cash_amount { get; set; }

        /// <summary>
        /// 当前筹码合计
        /// </summary>
        public decimal now_coin_amount { get; set; }

        /// <summary>
        /// 当前现金合计
        /// </summary>
        public decimal now_cash_amount { get; set; }

        /// <summary>
        /// 开台时间
        /// </summary>
        public DateTime begin_time { get; set; }
    }
}
