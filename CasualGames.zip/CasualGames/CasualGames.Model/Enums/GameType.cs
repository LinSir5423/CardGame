﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.Enums
{
    /// <summary>
    /// 游戏类型
    /// </summary>
    public enum GameType
    {
        /// <summary>
        /// 1-百家乐
        /// </summary>
        [Description("百家乐")]
        Baccarat = 1,

        /// <summary>
        /// 2-龙虎
        /// </summary>
        [Description("龙虎")]
        Pred = 2,

        /// <summary>
        /// 3-牛牛
        /// </summary>
        [Description("牛牛")]
        Taurus = 3,

        /// <summary>
        /// 4-筒子
        /// </summary>
        [Description("筒子")]
        TongZi = 4,

        /// <summary>
        /// 5-双联
        /// </summary>
        [Description("双联")]
        ShuangLian = 5,

        /// <summary>
        /// 6-三公
        /// </summary>
        [Description("三公")]
        SanGong = 6
    }
}
