﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred.Dewdrop
{
    /// <summary>
    /// 龙虎露珠
    /// </summary>
    public class PredDewdropInfo : DewdropInfoBase
    {
        public PredDewdropInfo()
        {
            GridData = new ObservableCollection<PredDewdropInfoGrid>();
        }

        public ObservableCollection<PredDewdropInfoGrid> GridData { get; set; }
    }
}
