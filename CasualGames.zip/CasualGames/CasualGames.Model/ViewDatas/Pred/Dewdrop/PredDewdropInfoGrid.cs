﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred.Dewdrop
{
    /// <summary>
    /// 
    /// </summary>
    public class PredDewdropInfoGrid : BaccaratDewdropInfoGrid
    {
    }
}
