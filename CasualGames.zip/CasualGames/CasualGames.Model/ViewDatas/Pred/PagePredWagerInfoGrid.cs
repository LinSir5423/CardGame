﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred
{
    /// <summary>
    /// 龙虎录入页面绑定使用
    /// </summary>
    public class PagePredWagerInfoGrid : PredWagerInfoGrid
    {
        private bool _cashChecked;
        /// <summary>
        /// 现金
        /// </summary>
        public bool CashChecked
        {
            get
            {
                return _cashChecked;
            }
            set
            {
                _cashChecked = value;
                OnPropertyChanged("CashChecked");
            }
        }

        private bool _chipChecked;
        /// <summary>
        /// 筹码
        /// </summary>
        public bool ChipChecked
        {
            get
            {
                return _chipChecked;
            }
            set
            {
                _chipChecked = value;
                OnPropertyChanged("ChipChecked");
            }
        }
    }
}
