﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred
{
    /// <summary>
    /// 龙虎录入数据注单详情
    /// </summary>
    public class PredWriteRecordBet : BaccatatWriteRecordBet
    {
    }
}
