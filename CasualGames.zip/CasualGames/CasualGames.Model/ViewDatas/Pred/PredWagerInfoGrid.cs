﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred
{
    /// <summary>
    /// 龙虎注单表结构
    /// </summary>
    public class PredWagerInfoGrid : WagerInfoBase
    {
        private bool _hasData;
        /// <summary>
        /// 是否有数据
        /// </summary>
        public bool HasData
        {
            get
            {
                return _hasData;
            }
            set
            {
                _hasData = value;
                OnPropertyChanged("HasData");
            }
        }

        private int _index;
        /// <summary>
        /// 序号
        /// </summary>
        public int Index
        {
            get
            {
                return _index;
            }
            set
            {
                _index = value;
                OnPropertyChanged("Index");
            }
        }

        private string _userName;
        /// <summary>
        /// 账号
        /// </summary>
        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
                OnPropertyChanged("UserName");
            }
        }

        private int _userId;
        /// <summary>
        /// 账号ID
        /// </summary>
        public int UserId
        {
            get
            {
                return _userId;
            }
            set
            {
                _userId = value;
                OnPropertyChanged("UserId");
            }
        }

        private decimal _long;
        /// <summary>
        /// long
        /// </summary>
        public decimal Long
        {
            get
            {
                return Math.Round(_long, 2);
            }
            set
            {
                _long = value;
                OnPropertyChanged("Long");
            }
        }

        private string _longText;
        public string LongText
        {
            get
            {
                return _longText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _long = tempVale;
                _longText = value;
                OnPropertyChanged("LongText");
            }
        }

        private decimal _hu;
        /// <summary>
        /// 虎
        /// </summary>
        public decimal Hu
        {
            get
            {
                return Math.Round(_hu, 2);
            }
            set
            {
                _hu = value;
                OnPropertyChanged("Hu");
            }
        }

        private string _huText;
        public string HuText
        {
            get
            {
                return _huText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _hu = tempVale;
                _huText = value;
                OnPropertyChanged("HuText");
            }
        }

        private decimal _he;
        /// <summary>
        /// 和
        /// </summary>
        public decimal He
        {
            get
            {
                return Math.Round(_he, 2);
            }
            set
            {
                _he = value;
                OnPropertyChanged("He");
            }
        }

        private string _heText;
        public string HeText
        {
            get
            {
                return _heText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _he = tempVale;
                _heText = value;
                OnPropertyChanged("HeText");
            }
        }

        private bool _cashType;
        /// <summary>
        /// 资金类型 True：现金 False：筹码
        /// </summary>
        public bool CashType
        {
            get
            {
                return _cashType;
            }
            set
            {
                _cashType = value;
                OnPropertyChanged("CashType");
            }
        }

        private bool _cashChecked;
        /// <summary>
        /// 现金
        /// </summary>
        public bool CashChecked
        {
            get
            {
                return _cashChecked;
            }
            set
            {
                _cashChecked = value;
                _chipChecked = !value;
                _cashType = _cashChecked == true ? true : false;
                OnPropertyChanged("CashChecked");
            }
        }

        private bool _chipChecked;
        /// <summary>
        /// 筹码
        /// </summary>
        public bool ChipChecked
        {
            get
            {
                return _chipChecked;
            }
            set
            {
                _chipChecked = value;
                _cashChecked = !value;
                _cashType = _chipChecked == true ? false : true;
                OnPropertyChanged("ChipChecked");
            }
        }
    }
}
