﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred
{
    /// <summary>
    /// 龙虎游戏的基础信息【左上角部分】
    /// </summary>
    public class PredBaseInfo : WagerInfoBase
    {

        private decimal _allLong;
        /// <summary>
        /// 龙注单数据综合
        /// </summary>
        public decimal AllLong
        {
            get
            {
                return Math.Round(_allLong, 2);
            }
            set
            {
                _allLong = value;
                OnPropertyChanged("AllLong");
            }
        }

        private decimal _allHu;
        /// <summary>
        /// 虎注单数据综合
        /// </summary>
        public decimal AllHu
        {
            get
            {
                return Math.Round(_allHu, 2);
            }
            set
            {
                _allHu = value;
                OnPropertyChanged("AllHu");
            }
        }

        private decimal _allHe;
        /// <summary>
        /// 和注单数据综合
        /// </summary>
        public decimal AllHe
        {
            get
            {
                return Math.Round(_allHe, 2);
            }
            set
            {
                _allHe = value;
                OnPropertyChanged("AllHe");
            }
        }

        private int _taiNumber;
        /// <summary>
        /// 台号
        /// </summary>
        public int TaiNumber
        {
            get
            {
                return _taiNumber;
            }
            set
            {
                _taiNumber = value;
                OnPropertyChanged("TaiNumber");
            }
        }

        private string _showTime;
        /// <summary>
        /// 显示时间
        /// </summary>
        public string ShowTime
        {
            get
            {
                return _showTime;
            }
            set
            {
                _showTime = value;
                OnPropertyChanged("ShowTime");
            }
        }

        private int _chang;
        /// <summary>
        /// 场号
        /// </summary>
        public int Chang
        {
            get
            {
                return _chang;
            }
            set
            {
                _chang = value;
                OnPropertyChanged("Chang");
            }
        }

        private int _ci;
        /// <summary>
        /// 次号
        /// </summary>
        public int Ci
        {
            get
            {
                return _ci;
            }
            set
            {
                _ci = value;
                OnPropertyChanged("Ci");
            }
        }

        private string _red;
        /// <summary>
        /// 限红
        /// </summary>
        public string Red
        {
            get
            {
                return _red;
            }
            set
            {
                _red = value;
                OnPropertyChanged("Red");
            }
        }

        private bool _longIsChecked;
        /// <summary>
        /// 龙是否选中
        /// </summary>
        public bool LongIsChecked
        {
            get
            {
                return _longIsChecked;
            }
            set
            {
                _longIsChecked = value;
                OnPropertyChanged("LongIsChecked");
            }
        }

        private bool _huIsChecked;
        /// <summary>
        /// 虎是否选中
        /// </summary>
        public bool HuIsChecked
        {
            get
            {
                return _huIsChecked;
            }
            set
            {
                _huIsChecked = value;
                OnPropertyChanged("HuIsChecked");
            }
        }

        private bool _heIsChecked;
        /// <summary>
        /// 和是否选中
        /// </summary>
        public bool HeIsChecked
        {
            get
            {
                return _heIsChecked;
            }
            set
            {
                _heIsChecked = value;
                OnPropertyChanged("HeIsChecked");
            }
        }
    }
}
