﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Pred
{
    /// <summary>
    /// 龙虎注单信息
    /// </summary>
    public class PredWagerInfo : WagerInfoBase
    {
        public PredWagerInfo()
        {
            GridData = new ObservableCollection<PredWagerInfoGrid>();
        }

        public ObservableCollection<PredWagerInfoGrid> GridData { get; set; }
    }
}
