﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 
    /// </summary>
    public class ShiftChangeInfo : WagerInfoBase
    {
        private decimal _coin_win_total;
        /// <summary>
        /// 筹码总赢
        /// </summary>
        public decimal coin_win_total
        {
            get
            {
                return Math.Round(_coin_win_total, 2);
            }
            set
            {
                _coin_win_total = value;
                OnPropertyChanged("coin_win_total");
            }
        }

        private decimal _deduct_tie_total;
        /// <summary>
        /// 筹码和扣底
        /// </summary>
        public decimal deduct_tie_total
        {
            get
            {
                return Math.Round(_deduct_tie_total, 2);
            }
            set
            {
                _deduct_tie_total = value;
                OnPropertyChanged("deduct_tie_total");
            }
        }

        private decimal _deduct_pairs_total;
        /// <summary>
        /// 筹码对子扣底
        /// </summary>
        public decimal deduct_pairs_total
        {
            get
            {
                return Math.Round(_deduct_pairs_total, 2);
            }
            set
            {
                _deduct_pairs_total = value;
                OnPropertyChanged("deduct_pairs_total");
            }
        }

        private decimal _cash_win_total;
        /// <summary>
        /// 现金总赢
        /// </summary>
        public decimal cash_win_total
        {
            get
            {
                return Math.Round(_deduct_pairs_total, 2);
            }
            set
            {
                _cash_win_total = value;
                OnPropertyChanged("cash_win_total");
            }
        }

        private decimal _cash_deduct_tie_total;
        /// <summary>
        /// 现金和扣底
        /// </summary>
        public decimal cash_deduct_tie_total
        {
            get
            {
                return Math.Round(_cash_deduct_tie_total, 2);
            }
            set
            {
                _cash_deduct_tie_total = value;
                OnPropertyChanged("cash_deduct_tie_total");
            }
        }

        private decimal _cash_deduct_pairs_total;
        /// <summary>
        /// 现金筹码扣底
        /// </summary>
        public decimal cash_deduct_pairs_total
        {
            get
            {
                return Math.Round(_cash_deduct_pairs_total, 2);
            }
            set
            {
                _cash_deduct_pairs_total = value;
                OnPropertyChanged("cash_deduct_pairs_total");
            }
        }

        private decimal _init_coin_amount;
        /// <summary>
        /// 初始化筹码金额
        /// </summary>
        public decimal init_coin_amount
        {
            get
            {
                return Math.Round(_init_coin_amount, 2);
            }
            set
            {
                _init_coin_amount = value;
                OnPropertyChanged("init_coin_amount");
            }
        }

        private decimal _init_cash_amount;
        /// <summary>
        /// 初始化现金金额
        /// </summary>
        public decimal init_cash_amount
        {
            get
            {
                return Math.Round(_init_cash_amount, 2);
            }
            set
            {
                _init_cash_amount = value;
                OnPropertyChanged("init_cash_amount");
            }
        }

        private decimal _now_coin_amount;
        /// <summary>
        /// 当前筹码合计
        /// </summary>
        public decimal now_coin_amount
        {
            get
            {
                return Math.Round(_now_coin_amount, 2);
            }
            set
            {
                _now_coin_amount = value;
                OnPropertyChanged("now_coin_amount");
            }
        }

        private decimal _now_cash_amount;
        /// <summary>
        /// 当前现金合计
        /// </summary>
        public decimal now_cash_amount
        {
            get
            {
                return Math.Round(_now_cash_amount, 2);
            }
            set
            {
                _now_cash_amount = value;
                OnPropertyChanged("now_cash_amount");
            }
        }

        private DateTime _begin_time;
        /// <summary>
        /// 开台时间
        /// </summary>
        public DateTime begin_time
        {
            get
            {
                return _begin_time;
            }
            set
            {
                _begin_time = value;
                OnPropertyChanged("begin_time");
            }
        }
    }
}
