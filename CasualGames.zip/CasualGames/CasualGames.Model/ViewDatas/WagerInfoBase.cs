﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 
    /// </summary>
    public class WagerInfoBase : INotifyPropertyChanged
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="propertyName"></param>
        protected internal virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
