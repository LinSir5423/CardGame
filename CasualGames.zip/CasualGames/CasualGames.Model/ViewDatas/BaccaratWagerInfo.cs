﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 百家乐注单信息
    /// </summary>
    public class BaccaratWagerInfo : WagerInfoBase
    {
        public BaccaratWagerInfo()
        {
            GridData = new ObservableCollection<BaccaratWagerInfoGrid>();
        }

        public ObservableCollection<BaccaratWagerInfoGrid> GridData { get; set; }

    }

    public class BaccaratWagerInfoGrid : WagerInfoBase
    {
        private bool _hasData;
        /// <summary>
        /// 是否有数据
        /// </summary>
        public bool HasData
        {
            get
            {
                return _hasData;
            }
            set
            {
                _hasData = value;
                OnPropertyChanged("HasData");
            }
        }

        private int _index;
        /// <summary>
        /// 序号
        /// </summary>
        public int Index
        {
            get
            {
                return _index;
            }
            set
            {
                _index = value;
                OnPropertyChanged("Index");
            }
        }

        private string _userName;
        /// <summary>
        /// 账号
        /// </summary>
        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
                OnPropertyChanged("UserName");
            }
        }

        private int _userId;
        /// <summary>
        /// 账号ID
        /// </summary>
        public int UserId
        {
            get
            {
                return _userId;
            }
            set
            {
                _userId = value;
                OnPropertyChanged("UserId");
            }
        }

        private decimal _zhuang;
        /// <summary>
        /// 庄
        /// </summary>
        public decimal Zhuang
        {
            get
            {
                return Math.Round(_zhuang, 2);
            }
            set
            {
                _zhuang = value;
                OnPropertyChanged("Zhuang");
            }
        }

        private string _zhuangText;
        public string ZhuangText
        {
            get
            {
                return _zhuangText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _zhuang = tempVale;
                _zhuangText = value;
                OnPropertyChanged("ZhuangText");
            }
        }

        private decimal _xian;
        /// <summary>
        /// 闲
        /// </summary>
        public decimal Xian
        {
            get
            {
                return Math.Round(_xian, 2);
            }
            set
            {
                _xian = value;
                OnPropertyChanged("Xian");
            }
        }


        private string _xianText;
        public string XianText
        {
            get
            {
                return _xianText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xian = tempVale;
                _xianText = value;
                OnPropertyChanged("XianText");
            }
        }

        private decimal _he;
        /// <summary>
        /// 和
        /// </summary>
        public decimal He
        {
            get
            {
                return Math.Round(_he, 2);
            }
            set
            {
                _he = value;
                OnPropertyChanged("He");
            }
        }

        private string _heText;
        public string HeText
        {
            get
            {
                return _heText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _he = tempVale;
                _heText = value;
                OnPropertyChanged("HeText");
            }
        }

        private decimal _zhuangDui;
        /// <summary>
        /// 庄对
        /// </summary>
        public decimal ZhuangDui
        {
            get
            {
                return Math.Round(_zhuangDui, 2);
            }
            set
            {
                _zhuangDui = value;
                OnPropertyChanged("ZhuangDui");
            }
        }

        private string _zhuangDuiText;
        public string ZhuangDuiText
        {
            get
            {
                return _zhuangDuiText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _zhuangDui = tempVale;
                _zhuangDuiText = value;
                OnPropertyChanged("ZhuangDuiText");
            }
        }

        private decimal _xianDui;
        /// <summary>
        /// 闲对
        /// </summary>
        public decimal XianDui
        {
            get
            {
                return Math.Round(_xianDui, 2);
            }
            set
            {
                _xianDui = value;
                OnPropertyChanged("XianDui");
            }
        }

        private string _xianDuiText;
        public string XianDuiText
        {
            get
            {
                return _xianDuiText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianDui = tempVale;
                _xianDuiText = value;
                OnPropertyChanged("XianDuiText");
            }
        }

        private bool _cashType;
        /// <summary>
        /// 资金类型 True：现金 False：筹码
        /// </summary>
        public bool CashType
        {
            get
            {
                return _cashType;
            }
            set
            {
                _cashType = value;
                OnPropertyChanged("CashType");
            }
        }

        private bool _cashChecked;
        /// <summary>
        /// 现金
        /// </summary>
        public bool CashChecked
        {
            get
            {
                return _cashChecked;
            }
            set
            {
                _cashChecked = value;
                _chipChecked = !value;
                _cashType = _cashChecked == true ? true : false;
                OnPropertyChanged("CashChecked");
            }
        }

        private bool _chipChecked;
        /// <summary>
        /// 筹码
        /// </summary>
        public bool ChipChecked
        {
            get
            {
                return _chipChecked;
            }
            set
            {
                _chipChecked = value;
                _cashChecked = !value;
                _cashType = _chipChecked == true ? false : true;
                OnPropertyChanged("ChipChecked");
            }
        }
    }

    /// <summary>
    /// 页面绑定使用
    /// </summary>
    public class PageBaccaratWagerInfoGrid : BaccaratWagerInfoGrid
    {
        private bool _cashChecked;
        /// <summary>
        /// 现金
        /// </summary>
        public bool CashChecked
        {
            get
            {
                return _cashChecked;
            }
            set
            {
                _cashChecked = value;
                OnPropertyChanged("CashChecked");
            }
        }

        private bool _chipChecked;
        /// <summary>
        /// 筹码
        /// </summary>
        public bool ChipChecked
        {
            get
            {
                return _chipChecked;
            }
            set
            {
                _chipChecked = value;
                OnPropertyChanged("ChipChecked");
            }
        }
    }
}
