﻿using CasualGames.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 
    /// </summary>
    public class GameRecordInfoGrid
    {
        /// <summary>
        /// 记录ID
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int user_id { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// 台号
        /// </summary>
        public int game_id { get; set; }

        /// <summary>
        /// 游戏类型
        /// </summary>
        public GameType game_type { get; set; }

        /// <summary>
        /// 场
        /// </summary>
        public string chang { get; set; }

        /// <summary>
        /// 次
        /// </summary>
        public string ci { get; set; }

        /// <summary>
        /// 下注详情
        /// </summary>
        public string bet_txt { get; set; }

        /// <summary>
        /// 游戏结果
        /// </summary>
        public string game_result { get; set; }

        /// <summary>
        /// 输赢金额
        /// </summary>
        public decimal win_total { get; set; }

        /// <summary>
        /// 洗码量
        /// </summary>
        public decimal double_wash_code { get; set; }

        /// <summary>
        /// 输赢 true为赢 false为输
        /// </summary>
        public bool is_win { get; set; }

        /// <summary>
        /// 筹码现金 true为现金 false为筹码
        /// </summary>
        public bool is_cash { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string remark { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime create_time { get; set; }
    }
}
