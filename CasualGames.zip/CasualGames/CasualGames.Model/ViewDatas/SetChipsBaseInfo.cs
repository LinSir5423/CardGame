﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 
    /// </summary>
    public class SetChipsBaseInfo : ShiftChangeInfo
    {
        private decimal _setChouMa;
        /// <summary>
        /// 设置筹码
        /// </summary>
        public decimal SetChouMa
        {
            get
            {
                return Math.Round(_setChouMa, 2);
            }
            set
            {
                _setChouMa = value;
                OnPropertyChanged("SetChouMa");
            }
        }

        private decimal _setXianJin;
        /// <summary>
        /// 设置现金
        /// </summary>
        public decimal SetXianJin
        {
            get
            {
                return Math.Round(_setXianJin, 2);
            }
            set
            {
                _setXianJin = value;
                OnPropertyChanged("SetXianJin");
            }
        }

        private decimal _addChouMa;
        /// <summary>
        /// 加筹码
        /// </summary>
        public decimal AddChouMa
        {
            get
            {
                return Math.Round(_addChouMa, 2);
            }
            set
            {
                _addChouMa = value;
                OnPropertyChanged("AddChouMa");
            }
        }

        private decimal _subtractChouMa;
        /// <summary>
        /// 减筹码
        /// </summary>
        public decimal SubtractChouMa
        {
            get
            {
                return Math.Round(_subtractChouMa, 2);
            }
            set
            {
                _subtractChouMa = value;
                OnPropertyChanged("SubtractChouMa");
            }
        }

        private decimal _AddXianJin;
        /// <summary>
        /// 加现金
        /// </summary>
        public decimal AddXianJin
        {
            get
            {
                return Math.Round(_AddXianJin, 2);
            }
            set
            {
                _AddXianJin = value;
                OnPropertyChanged("AddXianJin");
            }
        }

        private decimal _subtractXianJin;
        /// <summary>
        /// 减现金
        /// </summary>
        public decimal SubtractXianJin
        {
            get
            {
                return Math.Round(_subtractXianJin, 2);
            }
            set
            {
                _subtractXianJin = value;
                OnPropertyChanged("SubtractXianJin");
            }
        }
    }
}
