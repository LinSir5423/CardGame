﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 台桌统计数据结构
    /// </summary>
    public class GameRecordInfo
    {
        /// <summary>
        /// 筹码总输赢
        /// </summary>
        public decimal coin_win_total { get; set; }

        /// <summary>
        /// 现金总输赢
        /// </summary>
        public decimal cash_win_total { get; set; }

        /// <summary>
        /// 洗码量
        /// </summary>
        public decimal xima_amount { get; set; }

        /// <summary>
        /// 列表数据
        /// </summary>
        public List<GameRecordInfoGrid> Data { get; set; }
    }
}
