﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 百家乐露珠
    /// </summary>
    public class BaccaratDewdropInfo : DewdropInfoBase
    {
        public BaccaratDewdropInfo()
        {
            GridData = new ObservableCollection<BaccaratDewdropInfoGrid>();
        }

        public ObservableCollection<BaccaratDewdropInfoGrid> GridData { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class BaccaratDewdropInfoGrid : DewdropInfoBase
    {
        private string _gridData01;
        /// <summary>
        /// 01列数据
        /// </summary>
        public string GridData01
        {
            get
            {
                return _gridData01;
            }
            set
            {
                _gridData01 = value;
                OnPropertyChanged("GridData01");
            }
        }


        private string _gridData02;
        /// <summary>
        /// 02列数据
        /// </summary>
        public string GridData02
        {
            get
            {
                return _gridData02;
            }
            set
            {
                _gridData02 = value;
                OnPropertyChanged("GridData02");
            }
        }


        private string _gridData03;
        /// <summary>
        /// 03列数据
        /// </summary>
        public string GridData03
        {
            get
            {
                return _gridData03;
            }
            set
            {
                _gridData03 = value;
                OnPropertyChanged("GridData03");
            }
        }


        private string _gridData04;
        /// <summary>
        /// 04列数据
        /// </summary>
        public string GridData04
        {
            get
            {
                return _gridData04;
            }
            set
            {
                _gridData04 = value;
                OnPropertyChanged("GridData04");
            }
        }


        private string _gridData05;
        /// <summary>
        /// 05列数据
        /// </summary>
        public string GridData05
        {
            get
            {
                return _gridData05;
            }
            set
            {
                _gridData05 = value;
                OnPropertyChanged("GridData05");
            }
        }


        private string _gridData06;
        /// <summary>
        /// 06列数据
        /// </summary>
        public string GridData06
        {
            get
            {
                return _gridData06;
            }
            set
            {
                _gridData06 = value;
                OnPropertyChanged("GridData06");
            }
        }


        private string _gridData07;
        /// <summary>
        /// 07列数据
        /// </summary>
        public string GridData07
        {
            get
            {
                return _gridData07;
            }
            set
            {
                _gridData07 = value;
                OnPropertyChanged("GridData07");
            }
        }


        private string _gridData08;
        /// <summary>
        /// 08列数据
        /// </summary>
        public string GridData08
        {
            get
            {
                return _gridData08;
            }
            set
            {
                _gridData08 = value;
                OnPropertyChanged("GridData08");
            }
        }


        private string _gridData09;
        /// <summary>
        /// 09列数据
        /// </summary>
        public string GridData09
        {
            get
            {
                return _gridData09;
            }
            set
            {
                _gridData09 = value;
                OnPropertyChanged("GridData09");
            }
        }


        private string _gridData10;
        /// <summary>
        /// 10列数据
        /// </summary>
        public string GridData10
        {
            get
            {
                return _gridData10;
            }
            set
            {
                _gridData10 = value;
                OnPropertyChanged("GridData10");
            }
        }


        private string _gridData11;
        /// <summary>
        /// 11列数据
        /// </summary>
        public string GridData11
        {
            get
            {
                return _gridData11;
            }
            set
            {
                _gridData11 = value;
                OnPropertyChanged("GridData11");
            }
        }


        private string _gridData12;
        /// <summary>
        /// 12列数据
        /// </summary>
        public string GridData12
        {
            get
            {
                return _gridData12;
            }
            set
            {
                _gridData12 = value;
                OnPropertyChanged("GridData12");
            }
        }


        private string _gridData13;
        /// <summary>
        /// 13列数据
        /// </summary>
        public string GridData13
        {
            get
            {
                return _gridData13;
            }
            set
            {
                _gridData13 = value;
                OnPropertyChanged("GridData13");
            }
        }


        private string _gridData14;
        /// <summary>
        /// 14列数据
        /// </summary>
        public string GridData14
        {
            get
            {
                return _gridData14;
            }
            set
            {
                _gridData14 = value;
                OnPropertyChanged("GridData14");
            }
        }


        private string _gridData15;
        /// <summary>
        /// 15列数据
        /// </summary>
        public string GridData15
        {
            get
            {
                return _gridData15;
            }
            set
            {
                _gridData15 = value;
                OnPropertyChanged("GridData15");
            }
        }


        private string _gridData16;
        /// <summary>
        /// 16列数据
        /// </summary>
        public string GridData16
        {
            get
            {
                return _gridData16;
            }
            set
            {
                _gridData16 = value;
                OnPropertyChanged("GridData16");
            }
        }


        private string _gridData17;
        /// <summary>
        /// 17列数据
        /// </summary>
        public string GridData17
        {
            get
            {
                return _gridData17;
            }
            set
            {
                _gridData17 = value;
                OnPropertyChanged("GridData17");
            }
        }


        private string _gridData18;
        /// <summary>
        /// 18列数据
        /// </summary>
        public string GridData18
        {
            get
            {
                return _gridData18;
            }
            set
            {
                _gridData18 = value;
                OnPropertyChanged("GridData18");
            }
        }


        private string _gridData19;
        /// <summary>
        /// 19列数据
        /// </summary>
        public string GridData19
        {
            get
            {
                return _gridData19;
            }
            set
            {
                _gridData19 = value;
                OnPropertyChanged("GridData19");
            }
        }


        private string _gridData20;
        /// <summary>
        /// 20列数据
        /// </summary>
        public string GridData20
        {
            get
            {
                return _gridData20;
            }
            set
            {
                _gridData20 = value;
                OnPropertyChanged("GridData20");
            }
        }


        private string _gridData21;
        /// <summary>
        /// 21列数据
        /// </summary>
        public string GridData21
        {
            get
            {
                return _gridData21;
            }
            set
            {
                _gridData21 = value;
                OnPropertyChanged("GridData21");
            }
        }


        private string _gridData22;
        /// <summary>
        /// 22列数据
        /// </summary>
        public string GridData22
        {
            get
            {
                return _gridData22;
            }
            set
            {
                _gridData22 = value;
                OnPropertyChanged("GridData22");
            }
        }


        private string _gridData23;
        /// <summary>
        /// 23列数据
        /// </summary>
        public string GridData23
        {
            get
            {
                return _gridData23;
            }
            set
            {
                _gridData23 = value;
                OnPropertyChanged("GridData23");
            }
        }


        private string _gridData24;
        /// <summary>
        /// 24列数据
        /// </summary>
        public string GridData24
        {
            get
            {
                return _gridData24;
            }
            set
            {
                _gridData24 = value;
                OnPropertyChanged("GridData24");
            }
        }


        private string _gridData25;
        /// <summary>
        /// 25列数据
        /// </summary>
        public string GridData25
        {
            get
            {
                return _gridData25;
            }
            set
            {
                _gridData25 = value;
                OnPropertyChanged("GridData25");
            }
        }
    }
}
