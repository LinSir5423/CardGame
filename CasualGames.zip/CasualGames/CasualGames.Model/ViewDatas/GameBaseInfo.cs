﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas
{
    /// <summary>
    /// 游戏的基础信息【左上角部分】
    /// </summary>
    public class GameBaseInfo : WagerInfoBase
    {

        private decimal _allZhaung;
        /// <summary>
        /// 庄注单数据综合
        /// </summary>
        public decimal AllZhaung
        {
            get
            {
                return Math.Round(_allZhaung, 2);
            }
            set
            {
                _allZhaung = value;
                OnPropertyChanged("AllZhaung");
            }
        }

        private decimal _allXian;
        /// <summary>
        /// 闲注单数据综合
        /// </summary>
        public decimal AllXian
        {
            get
            {
                return Math.Round(_allXian, 2);
            }
            set
            {
                _allXian = value;
                OnPropertyChanged("AllXian");
            }
        }

        private decimal _allHe;
        /// <summary>
        /// 和注单数据综合
        /// </summary>
        public decimal AllHe
        {
            get
            {
                return Math.Round(_allHe, 2);
            }
            set
            {
                _allHe = value;
                OnPropertyChanged("AllHe");
            }
        }

        private decimal _allZhuangDui;
        /// <summary>
        /// 庄对注单数据综合
        /// </summary>
        public decimal AllZhuangDui
        {
            get
            {
                return Math.Round(_allZhuangDui, 2);
            }
            set
            {
                _allZhuangDui = value;
                OnPropertyChanged("AllZhuangDui");
            }
        }

        private decimal _allXianDui;
        /// <summary>
        /// 闲对注单数据综合
        /// </summary>
        public decimal AllXianDui
        {
            get
            {
                return Math.Round(_allXianDui, 2);
            }
            set
            {
                _allXianDui = value;
                OnPropertyChanged("AllXianDui");
            }
        }

        private int _taiNumber;
        /// <summary>
        /// 台号
        /// </summary>
        public int TaiNumber
        {
            get
            {
                return _taiNumber;
            }
            set
            {
                _taiNumber = value;
                OnPropertyChanged("TaiNumber");
            }
        }

        private string _showTime;
        /// <summary>
        /// 显示时间
        /// </summary>
        public string ShowTime
        {
            get
            {
                return _showTime;
            }
            set
            {
                _showTime = value;
                OnPropertyChanged("ShowTime");
            }
        }

        private int _chang;
        /// <summary>
        /// 场号
        /// </summary>
        public int Chang
        {
            get
            {
                return _chang;
            }
            set
            {
                _chang = value;
                OnPropertyChanged("Chang");
            }
        }

        private int _ci;
        /// <summary>
        /// 次号
        /// </summary>
        public int Ci
        {
            get
            {
                return _ci;
            }
            set
            {
                _ci = value;
                OnPropertyChanged("Ci");
            }
        }

        private string _red;
        /// <summary>
        /// 限红
        /// </summary>
        public string Red
        {
            get
            {
                return _red;
            }
            set
            {
                _red = value;
                OnPropertyChanged("Red");
            }
        }

        private bool _zhuangIsChecked;
        /// <summary>
        /// 装是否选中
        /// </summary>
        public bool ZhuangIsChecked
        {
            get
            {
                return _zhuangIsChecked;
            }
            set
            {
                _zhuangIsChecked = value;
                OnPropertyChanged("ZhuangIsChecked");
            }
        }

        private bool _xianIsChecked;
        /// <summary>
        /// 闲是否选中
        /// </summary>
        public bool XianIsChecked
        {
            get
            {
                return _xianIsChecked;
            }
            set
            {
                _xianIsChecked = value;
                OnPropertyChanged("XianIsChecked");
            }
        }

        private bool _heIsChecked;
        /// <summary>
        /// 和是否选中
        /// </summary>
        public bool HeIsChecked
        {
            get
            {
                return _heIsChecked;
            }
            set
            {
                _heIsChecked = value;
                OnPropertyChanged("HeIsChecked");
            }
        }

        private bool _zhuangDuiIsChecked;
        /// <summary>
        /// 庄对是否选中
        /// </summary>
        public bool ZhuangDuiIsChecked
        {
            get
            {
                return _zhuangDuiIsChecked;
            }
            set
            {
                _zhuangDuiIsChecked = value;
                OnPropertyChanged("ZhuangDuiIsChecked");
            }
        }

        private bool _xianDuiIsChecked;
        /// <summary>
        /// 闲对是否选中
        /// </summary>
        public bool XianDuiIsChecked
        {
            get
            {
                return _xianDuiIsChecked;
            }
            set
            {
                _xianDuiIsChecked = value;
                OnPropertyChanged("XianDuiIsChecked");
            }
        }
    }
}
