﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Taurus
{
    /// <summary>
    /// 牛牛露珠
    /// </summary>
    public class TaurusDewdropInfo : DewdropInfoBase
    {
        public TaurusDewdropInfo()
        {
            GridData = new ObservableCollection<TaurusDewdropInfoGrid>();
        }

        public ObservableCollection<TaurusDewdropInfoGrid> GridData { get; set; }
    }
}
