﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Taurus
{
    /// <summary>
    /// 牛牛游戏的基础信息【左上角部分】
    /// </summary>
    public class TaurusBaseInfo : WagerInfoBase
    {

        private decimal _allXianYi;
        /// <summary>
        /// 闲一注单数据综合
        /// </summary>
        public decimal AllXianYi
        {
            get
            {
                return Math.Round(_allXianYi, 2);
            }
            set
            {
                _allXianYi = value;
                OnPropertyChanged("AllXianYi");
            }
        }

        private decimal _allXianEr;
        /// <summary>
        /// 闲二注单数据综合
        /// </summary>
        public decimal AllXianEr
        {
            get
            {
                return Math.Round(_allXianEr, 2);
            }
            set
            {
                _allXianEr = value;
                OnPropertyChanged("AllXianEr");
            }
        }

        private decimal _allXianSan;
        /// <summary>
        /// 闲三注单数据综合
        /// </summary>
        public decimal AllXianSan
        {
            get
            {
                return Math.Round(_allXianSan, 2);
            }
            set
            {
                _allXianSan = value;
                OnPropertyChanged("AllXianSan");
            }
        }

        private decimal _allXianSi;
        /// <summary>
        /// 闲四注单数据综合
        /// </summary>
        public decimal AllXianSi
        {
            get
            {
                return Math.Round(_allXianSi, 2);
            }
            set
            {
                _allXianSi = value;
                OnPropertyChanged("AllXianSi");
            }
        }

        private decimal _allXianWu;
        /// <summary>
        /// 闲五注单数据综合
        /// </summary>
        public decimal AllXianWu
        {
            get
            {
                return Math.Round(_allXianWu, 2);
            }
            set
            {
                _allXianWu = value;
                OnPropertyChanged("AllXianWu");
            }
        }

        private decimal _allXianLiu;
        /// <summary>
        /// 闲六注单数据综合
        /// </summary>
        public decimal AllXianLiu
        {
            get
            {
                return Math.Round(_allXianLiu, 2);
            }
            set
            {
                _allXianLiu = value;
                OnPropertyChanged("AllXianLiu");
            }
        }

        private int _taiNumber;
        /// <summary>
        /// 台号
        /// </summary>
        public int TaiNumber
        {
            get
            {
                return _taiNumber;
            }
            set
            {
                _taiNumber = value;
                OnPropertyChanged("TaiNumber");
            }
        }

        private string _showTime;
        /// <summary>
        /// 显示时间
        /// </summary>
        public string ShowTime
        {
            get
            {
                return _showTime;
            }
            set
            {
                _showTime = value;
                OnPropertyChanged("ShowTime");
            }
        }

        private int _chang;
        /// <summary>
        /// 场号
        /// </summary>
        public int Chang
        {
            get
            {
                return _chang;
            }
            set
            {
                _chang = value;
                OnPropertyChanged("Chang");
            }
        }

        private int _ci;
        /// <summary>
        /// 次号
        /// </summary>
        public int Ci
        {
            get
            {
                return _ci;
            }
            set
            {
                _ci = value;
                OnPropertyChanged("Ci");
            }
        }

        private string _red;
        /// <summary>
        /// 限红
        /// </summary>
        public string Red
        {
            get
            {
                return _red;
            }
            set
            {
                _red = value;
                OnPropertyChanged("Red");
            }
        }

        private bool _xianYiIsChecked;
        /// <summary>
        /// 闲一是否选中
        /// </summary>
        public bool XianYiIsChecked
        {
            get
            {
                return _xianYiIsChecked;
            }
            set
            {
                _xianYiIsChecked = value;
                OnPropertyChanged("XianYiIsChecked");
            }
        }

        private bool _xianErIsChecked;
        /// <summary>
        /// 闲二是否选中
        /// </summary>
        public bool XianErIsChecked
        {
            get
            {
                return _xianErIsChecked;
            }
            set
            {
                _xianErIsChecked = value;
                OnPropertyChanged("XianErIsChecked");
            }
        }

        private bool _xianSanIsChecked;
        /// <summary>
        /// 闲三是否选中
        /// </summary>
        public bool XianSanIsChecked
        {
            get
            {
                return _xianSanIsChecked;
            }
            set
            {
                _xianSanIsChecked = value;
                OnPropertyChanged("XianSanIsChecked");
            }
        }

        private bool _xianSiIsChecked;
        /// <summary>
        /// 闲四是否选中
        /// </summary>
        public bool XianSiIsChecked
        {
            get
            {
                return _xianSiIsChecked;
            }
            set
            {
                _xianSiIsChecked = value;
                OnPropertyChanged("XianSiIsChecked");
            }
        }

        private bool _xianWuIsChecked;
        /// <summary>
        /// 闲五是否选中
        /// </summary>
        public bool XianWuIsChecked
        {
            get
            {
                return _xianWuIsChecked;
            }
            set
            {
                _xianWuIsChecked = value;
                OnPropertyChanged("XianWuIsChecked");
            }
        }

        private bool _xianLiuIsChecked;
        /// <summary>
        /// 闲六是否选中
        /// </summary>
        public bool XianLiuIsChecked
        {
            get
            {
                return _xianLiuIsChecked;
            }
            set
            {
                _xianLiuIsChecked = value;
                OnPropertyChanged("XianLiuIsChecked");
            }
        }
    }
}
