﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Taurus
{
    public class TaurusWagerInfoGrid : WagerInfoBase
    {
        private bool _hasData;
        /// <summary>
        /// 是否有数据
        /// </summary>
        public bool HasData
        {
            get
            {
                return _hasData;
            }
            set
            {
                _hasData = value;
                OnPropertyChanged("HasData");
            }
        }

        private int _index;
        /// <summary>
        /// 序号
        /// </summary>
        public int Index
        {
            get
            {
                return _index;
            }
            set
            {
                _index = value;
                OnPropertyChanged("Index");
            }
        }

        private string _userName;
        /// <summary>
        /// 账号
        /// </summary>
        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
                OnPropertyChanged("UserName");
            }
        }

        private int _userId;
        /// <summary>
        /// 账号ID
        /// </summary>
        public int UserId
        {
            get
            {
                return _userId;
            }
            set
            {
                _userId = value;
                OnPropertyChanged("UserId");
            }
        }

        private decimal _xianYi;
        /// <summary>
        /// 闲一
        /// </summary>
        public decimal XianYi
        {
            get
            {
                return Math.Round(_xianYi, 2);
            }
            set
            {
                _xianYi = value;
                OnPropertyChanged("XianYi");
            }
        }

        private string _xianYiText;
        public string XianYiText
        {
            get
            {
                return _xianYiText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianYi = tempVale;
                _xianYiText = value;
                OnPropertyChanged("XianYiText");
            }
        }

        private decimal _xianEr;
        /// <summary>
        /// 闲二
        /// </summary>
        public decimal XianEr
        {
            get
            {
                return Math.Round(_xianEr, 2);
            }
            set
            {
                _xianEr = value;
                OnPropertyChanged("XianEr");
            }
        }

        private string _xianErText;
        public string XianErText
        {
            get
            {
                return _xianErText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianEr = tempVale;
                _xianErText = value;
                OnPropertyChanged("XianErText");
            }
        }

        private decimal _xianSan;
        /// <summary>
        /// 闲三
        /// </summary>
        public decimal XianSan
        {
            get
            {
                return Math.Round(_xianSan, 2);
            }
            set
            {
                _xianSan = value;
                OnPropertyChanged("XianSan");
            }
        }

        private string _xianSanText;
        public string XianSanText
        {
            get
            {
                return _xianSanText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianSan = tempVale;
                _xianSanText = value;
                OnPropertyChanged("XianSanText");
            }
        }

        private decimal _xianSi;
        /// <summary>
        /// 闲四
        /// </summary>
        public decimal XianSi
        {
            get
            {
                return Math.Round(_xianSi, 2);
            }
            set
            {
                _xianSi = value;
                OnPropertyChanged("XianSi");
            }
        }

        private string _xianSiText;
        public string XianSiText
        {
            get
            {
                return _xianSiText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianSi = tempVale;
                _xianSiText = value;
                OnPropertyChanged("XianSiText");
            }
        }

        private decimal _xianWu;
        /// <summary>
        /// 闲五
        /// </summary>
        public decimal XianWu
        {
            get
            {
                return Math.Round(_xianWu, 2);
            }
            set
            {
                _xianWu = value;
                OnPropertyChanged("XianWu");
            }
        }

        private string _xianWuText;
        public string XianWuText
        {
            get
            {
                return _xianWuText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianWu = tempVale;
                _xianWuText = value;
                OnPropertyChanged("XianWuText");
            }
        }

        private decimal _xianLiu;
        /// <summary>
        /// 闲六
        /// </summary>
        public decimal XianLiu
        {
            get
            {
                return Math.Round(_xianLiu, 2);
            }
            set
            {
                _xianLiu = value;
                OnPropertyChanged("XianLiu");
            }
        }

        private string _xianLiuText;
        public string XianLiuText
        {
            get
            {
                return _xianLiuText;
            }
            set
            {
                decimal tempVale = 0;
                decimal.TryParse(value, out tempVale);
                _xianLiu = tempVale;
                _xianLiuText = value;
                OnPropertyChanged("XianLiuText");
            }
        }

        private bool _cashType;
        /// <summary>
        /// 资金类型 True：现金 False：筹码
        /// </summary>
        public bool CashType
        {
            get
            {
                return _cashType;
            }
            set
            {
                _cashType = value;
                OnPropertyChanged("CashType");
            }
        }

        private bool _cashChecked;
        /// <summary>
        /// 现金
        /// </summary>
        public bool CashChecked
        {
            get
            {
                return _cashChecked;
            }
            set
            {
                _cashChecked = value;
                _chipChecked = !value;
                _cashType = _cashChecked == true ? true : false;
                OnPropertyChanged("CashChecked");
            }
        }

        private bool _chipChecked;
        /// <summary>
        /// 筹码
        /// </summary>
        public bool ChipChecked
        {
            get
            {
                return _chipChecked;
            }
            set
            {
                _chipChecked = value;
                _cashChecked = !value;
                _cashType = _chipChecked == true ? false : true;
                OnPropertyChanged("ChipChecked");
            }
        }
    }
}
