﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model.ViewDatas.Taurus
{
    /// <summary>
    /// 牛牛注单信息
    /// </summary>
    public class TaurusWagerInfo : WagerInfoBase
    {
        public TaurusWagerInfo()
        {
            GridData = new ObservableCollection<TaurusWagerInfoGrid>();
        }

        public ObservableCollection<TaurusWagerInfoGrid> GridData { get; set; }
    }
}
