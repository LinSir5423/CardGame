﻿using CasualGames.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class Loginer
    {
        /// <summary>
        /// 接口地址
        /// </summary>
        public static string ApiAddress { get; set; }

        /// <summary>
        /// 令牌有效长【单位秒】
        /// </summary>
        public static int ExpireInSeconds { get; set; }

        /// <summary>
        /// 刷新令牌
        /// </summary>
        public static string RefreshToken { get; set; }

        /// <summary>
        /// 最后登录时间
        /// </summary>
        public static DateTime LoginTime { get; set; }

        /// <summary>
        /// Token过期时间
        /// </summary>
        public static DateTime ExpirationTime { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public static string Password { get; set; }

        private static bool _openRefresh = true;
        /// <summary>
        /// 是否开启刷新
        /// </summary>
        public static bool OpenRefresh
        {
            get
            {
                return _openRefresh;
            }
            set
            {
                _openRefresh = value;
            }
        }



        /// <summary>
        /// 登录令牌
        /// </summary>
        public static string AccessToken { get; set; }

        /// <summary>
        /// 台ID
        /// </summary>
        public static int Id { get; set; }

        /// <summary>
        /// 台名称
        /// </summary>
        public static string GameName { get; set; }

        /// <summary>
        /// 游戏类型
        /// </summary>
        public static GameType GameType { get; set; }

        /// <summary>
        /// 限红
        /// </summary>
        public static string LimitRed { get; set; }

        /// <summary>
        /// 场
        /// </summary>
        public static int Chang { get; set; }

        /// <summary>
        /// 次
        /// </summary>
        public static int Ci { get; set; }

        /// <summary>
        /// 路单
        /// </summary>
        public static string RoadList { get; set; }
    }
}
