﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model
{
    /// <summary>
    /// 百家乐录入数据注单详情
    /// </summary>
    public class BaccatatWriteRecordBet
    {
        /// <summary>
        /// 用户账号
        /// </summary>
        public int user_id { get; set; }

        /// <summary>
        /// 账号名
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// 现金或筹码 true为现金
        /// </summary>
        public bool is_cash { get; set; }

        /// <summary>
        /// 注单详情
        /// </summary>
        public List<decimal> bet { get; set; }
    }
}
