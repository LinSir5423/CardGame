﻿using CasualGames.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasualGames.Model
{
    /// <summary>
    /// 登录返回数据模型
    /// </summary>
    public class LoginInfo
    {
        /// <summary>
        /// 台Id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 登录令牌
        /// </summary>
        public string token { get; set; }

        /// <summary>
        /// 台名称
        /// </summary>
        public string game_name { get; set; }

        /// <summary>
        /// 游戏类型
        /// </summary>
        public GameType game_type { get; set; }

        /// <summary>
        /// 限红
        /// </summary>
        public string limit_red { get; set; }

        /// <summary>
        /// 场
        /// </summary>
        public int chang { get; set; }

        /// <summary>
        /// 次
        /// </summary>
        public int ci { get; set; }

        /// <summary>
        /// 路单
        /// </summary>
        public string road_list { get; set; }
    }
}
